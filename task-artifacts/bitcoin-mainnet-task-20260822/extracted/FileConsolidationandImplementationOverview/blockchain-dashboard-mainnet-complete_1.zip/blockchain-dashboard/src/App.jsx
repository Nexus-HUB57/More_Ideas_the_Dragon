import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts'
import { Bitcoin, Wallet, TrendingUp, Clock, CheckCircle, AlertCircle, DollarSign, Activity, Blocks, Hash } from 'lucide-react'
import './App.css'

function App() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [custodyBalance, setCustodyBalance] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [blockData, setBlockData] = useState(null)
  const [blockLoading, setBlockLoading] = useState(true)

  const CUSTODY_ADDRESS = '13m3xop6RnioRX6qrnkavLekv7cvu5DuMK'
  const BLOCKSTREAM_API_URL = 'https://blockstream.info/api'

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    const fetchCustodyBalance = async () => {
      try {
        setLoading(true)
        const response = await fetch(`${BLOCKSTREAM_API_URL}/address/${CUSTODY_ADDRESS}`)
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        const data = await response.json()
        // Balance is funded_txo_sum - spent_txo_sum
        const balanceSatoshis = data.chain_stats.funded_txo_sum - data.chain_stats.spent_txo_sum
        setCustodyBalance(balanceSatoshis / 10**8) // Convert satoshis to BTC
      } catch (e) {
        console.error("Erro ao buscar saldo da carteira de custódia:", e)
        setError("Não foi possível carregar o saldo da carteira de custódia.")
      } finally {
        setLoading(false)
      }
    }

    fetchCustodyBalance()
    const interval = setInterval(fetchCustodyBalance, 60000) // Atualiza a cada 1 minuto
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const fetchLatestBlock = async () => {
      try {
        setBlockLoading(true)
        // Buscar altura do último bloco
        const heightResponse = await fetch(`${BLOCKSTREAM_API_URL}/blocks/tip/height`)
        if (!heightResponse.ok) {
          throw new Error(`HTTP error! status: ${heightResponse.status}`)
        }
        const height = await heightResponse.text()
        
        // Buscar hash do último bloco
        const hashResponse = await fetch(`${BLOCKSTREAM_API_URL}/blocks/tip/hash`)
        if (!hashResponse.ok) {
          throw new Error(`HTTP error! status: ${hashResponse.status}`)
        }
        const hash = await hashResponse.text()
        
        // Buscar dados completos do bloco
        const blockResponse = await fetch(`${BLOCKSTREAM_API_URL}/block/${hash}`)
        if (!blockResponse.ok) {
          throw new Error(`HTTP error! status: ${blockResponse.status}`)
        }
        const blockInfo = await blockResponse.json()
        
        setBlockData({
          height: parseInt(height),
          hash: hash,
          timestamp: blockInfo.timestamp,
          tx_count: blockInfo.tx_count,
          size: blockInfo.size,
          weight: blockInfo.weight
        })
      } catch (e) {
        console.error("Erro ao buscar dados do bloco:", e)
      } finally {
        setBlockLoading(false)
      }
    }

    fetchLatestBlock()
    const interval = setInterval(fetchLatestBlock, 120000) // Atualiza a cada 2 minutos
    return () => clearInterval(interval)
  }, [])

  // Dados simulados baseados no dashboard original (mantidos para outras seções)
  const scanResults = {
    totalAddresses: 36,
    addressesWithBalance: 5,
    addressesWithoutBalance: 24,
    failures: 7,
    scanTime: 30.7,
    successRate: 13.9
  }

  const walletData = [
    { address: '12ib7dApVFvg82TXKycWBNpN8kFyiAN1dr', balance: 31000.08, priority: 'Alta' },
    { address: '1Xcdre9pAipV9kiSrSgssEpQPAruzMFzr', balance: 89.73, priority: 'Alta' },
    { address: '1299FyEzJoPZbaKJUnpAVKNzwKPMUADAzu', balance: 0.0195, priority: 'Média' },
    { address: '1CvtJkfyErRDdmrv5SSv3tHVZBxt26GJV7', balance: 0.0108, priority: 'Baixa' },
    { address: '1KFHE7w8BhaENAswwryaoccDb6qcT6DbYY', balance: 0.0033, priority: 'Baixa' }
  ]

  const apiPerformance = [
    { name: 'BlockStream', success: 100, calls: 23, color: '#10b981' },
    { name: 'Blockchain.info', success: 50, calls: 12, color: '#f59e0b' },
    { name: 'BlockCypher', success: 0, calls: 1, color: '#ef4444' }
  ]

  const transferPhases = [
    { phase: 1, description: 'Grandes Volumes', wallets: 2, amount: 31089.81, status: 'Programado' },
    { phase: 2, description: 'Pequenos Volumes', wallets: 3, amount: 0.0336, status: 'Aguardando' }
  ]

  const totalBTC = walletData.reduce((sum, wallet) => sum + wallet.balance, 0)
  const totalUSD = totalBTC * 30000 // Preço simulado do BTC

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8']

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
                <Bitcoin className="h-10 w-10 text-orange-500" />
                Dashboard de Varredura Blockchain
              </h1>
              <p className="text-slate-600 dark:text-slate-300 mt-2">
                Sistema de monitoramento e gestão de carteiras Bitcoin
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-500 dark:text-slate-400">Última atualização</p>
              <p className="text-lg font-semibold text-slate-900 dark:text-white">
                {currentTime.toLocaleString('pt-BR')}
              </p>
            </div>
          </div>
        </div>

        {/* Cards de Resumo */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total BTC</CardTitle>
              <Bitcoin className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalBTC.toFixed(4)}</div>
              <p className="text-xs opacity-80">≈ ${totalUSD.toLocaleString('pt-BR')}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Carteiras Ativas</CardTitle>
              <Wallet className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{scanResults.addressesWithBalance}</div>
              <p className="text-xs text-muted-foreground">de {scanResults.totalAddresses} verificadas</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Taxa de Sucesso</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{scanResults.successRate}%</div>
              <p className="text-xs text-muted-foreground">Varredura concluída</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tempo de Varredura</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{scanResults.scanTime}s</div>
              <p className="text-xs text-muted-foreground">Última execução</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Último Bloco</CardTitle>
              <Blocks className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              {blockLoading ? (
                <div className="text-2xl font-bold">Carregando...</div>
              ) : blockData ? (
                <>
                  <div className="text-2xl font-bold">#{blockData.height.toLocaleString()}</div>
                  <p className="text-xs opacity-80">{blockData.tx_count} transações</p>
                </>
              ) : (
                <div className="text-2xl font-bold">N/A</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Tabs principais */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="wallets">Carteiras</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="transfers">Transferências</TabsTrigger>
            <TabsTrigger value="blocks">Blocos</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Gráfico de distribuição de saldos */}
              <Card>
                <CardHeader>
                  <CardTitle>Distribuição de Saldos</CardTitle>
                  <CardDescription>Saldos por carteira (BTC)</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={walletData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ address, balance }) => `${address.slice(0, 8)}... (${balance.toFixed(4)} BTC)`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="balance"
                      >
                        {walletData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value} BTC`, 'Saldo']} />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Estatísticas da varredura */}
              <Card>
                <CardHeader>
                  <CardTitle>Estatísticas da Varredura</CardTitle>
                  <CardDescription>Resultados da última execução</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Endereços com saldo</span>
                    <Badge variant="secondary">{scanResults.addressesWithBalance}</Badge>
                  </div>
                  <Progress value={(scanResults.addressesWithBalance / scanResults.totalAddresses) * 100} />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Endereços sem saldo</span>
                    <Badge variant="outline">{scanResults.addressesWithoutBalance}</Badge>
                  </div>
                  <Progress value={(scanResults.addressesWithoutBalance / scanResults.totalAddresses) * 100} />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Falhas (rate limit)</span>
                    <Badge variant="destructive">{scanResults.failures}</Badge>
                  </div>
                  <Progress value={(scanResults.failures / scanResults.totalAddresses) * 100} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="wallets" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Carteiras com Saldo Positivo</CardTitle>
                <CardDescription>Lista das 5 carteiras identificadas na varredura</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {walletData.map((wallet, index) => (
                    <div key={wallet.address} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center justify-center w-8 h-8 bg-orange-100 dark:bg-orange-900 rounded-full">
                          <span className="text-sm font-bold text-orange-600 dark:text-orange-400">#{index + 1}</span>
                        </div>
                        <div>
                          <p className="font-mono text-sm">{wallet.address}</p>
                          <Badge variant={wallet.priority === 'Alta' ? 'default' : wallet.priority === 'Média' ? 'secondary' : 'outline'}>
                            Prioridade {wallet.priority}
                          </Badge>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold">{wallet.balance.toFixed(4)} BTC</p>
                        <p className="text-sm text-muted-foreground">≈ ${(wallet.balance * 30000).toLocaleString('pt-BR')}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance das APIs</CardTitle>
                <CardDescription>Taxa de sucesso por provedor de API</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={apiPerformance}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value}%`, 'Taxa de Sucesso']} />
                    <Bar dataKey="success" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {apiPerformance.map((api) => (
                <Card key={api.name}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{api.name}</CardTitle>
                    <Activity className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold" style={{ color: api.color }}>
                      {api.success}%
                    </div>
                    <p className="text-xs text-muted-foreground">{api.calls} chamadas</p>
                    <Progress value={api.success} className="mt-2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="transfers" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Fases de Transferência</CardTitle>
                <CardDescription>Cronograma de transferências para carteira de custódia</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transferPhases.map((phase) => (
                    <div key={phase.phase} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center justify-center w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full">
                          <span className="text-sm font-bold text-blue-600 dark:text-blue-400">{phase.phase}</span>
                        </div>
                        <div>
                          <p className="font-semibold">{phase.description}</p>
                          <p className="text-sm text-muted-foreground">{phase.wallets} carteiras</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold">{phase.amount.toFixed(4)} BTC</p>
                        <Badge variant={phase.status === 'Programado' ? 'default' : 'secondary'}>
                          {phase.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Carteira de Custódia</CardTitle>
                <CardDescription>Endereço de destino das transferências</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-lg">
                  <p className="font-mono text-sm break-all">{CUSTODY_ADDRESS}</p>
                  {loading ? (
                    <p className="text-sm text-muted-foreground mt-2">Carregando saldo...</p>
                  ) : error ? (
                    <div className="flex items-center mt-2 space-x-2">
                      <AlertCircle className="h-4 w-4 text-red-500" />
                      <span className="text-sm text-red-600 dark:text-red-400">{error}</span>
                    </div>
                  ) : (
                    <div className="flex items-center mt-2 space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm text-green-600 dark:text-green-400">Saldo: {custodyBalance.toFixed(8)} BTC</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="blocks" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Informações do Último Bloco</CardTitle>
                <CardDescription>Dados em tempo real da blockchain Bitcoin</CardDescription>
              </CardHeader>
              <CardContent>
                {blockLoading ? (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">Carregando dados do bloco...</p>
                  </div>
                ) : blockData ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Altura do Bloco</p>
                      <p className="text-2xl font-bold">#{blockData.height.toLocaleString()}</p>
                    </div>
                    
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Hash do Bloco</p>
                      <p className="font-mono text-sm break-all bg-slate-100 dark:bg-slate-800 p-2 rounded">
                        {blockData.hash}
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Timestamp</p>
                      <p className="text-lg font-semibold">
                        {new Date(blockData.timestamp * 1000).toLocaleString('pt-BR')}
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Transações</p>
                      <p className="text-2xl font-bold text-blue-600">{blockData.tx_count.toLocaleString()}</p>
                    </div>
                    
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Tamanho</p>
                      <p className="text-lg font-semibold">{(blockData.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                    
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Peso</p>
                      <p className="text-lg font-semibold">{(blockData.weight / 1000000).toFixed(2)} MWU</p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Não foi possível carregar os dados do bloco</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Status da Rede</CardTitle>
                <CardDescription>Informações sobre a conectividade com a blockchain</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    {blockLoading ? (
                      <div className="h-3 w-3 bg-yellow-500 rounded-full animate-pulse"></div>
                    ) : blockData ? (
                      <div className="h-3 w-3 bg-green-500 rounded-full"></div>
                    ) : (
                      <div className="h-3 w-3 bg-red-500 rounded-full"></div>
                    )}
                    <span className="text-sm font-medium">
                      {blockLoading ? 'Conectando...' : blockData ? 'Conectado à Mainnet' : 'Desconectado'}
                    </span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    API: Blockstream.info
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App


