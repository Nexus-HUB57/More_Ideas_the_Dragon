# Dashboard 21 + PESBM (v4, nós públicos)

Este pacote unifica o seu **Dashboard 21** com a seção **PESBM** (Protocolo de Envio Seguro de Bitcoin via Mainnet),
usando **exploradores públicos** (Blockstream, com fallback opcional para BlockCypher).

## Estrutura
- `server.py` — Flask + CORS; endpoints:
  - `GET /api/address/<addr>`: saldo/UTXOs confirmados (Blockstream).
  - `GET /api/pesbm/status?txid=...`: confirmações e estado da transação (Blockstream).
  - `POST /api/pesbm/broadcast`: transmite RAW TX HEX (Blockstream; fallback BlockCypher).
- `static/index.html` — UI React via CDN (cards: Saldo, Status, PSBT/Broadcast).
- `legacy/` — conteúdo extraído do seu **Dashboard 21.zip** (OK (extraído em /legacy)).

## Como rodar
```bash
python -m venv .venv && source .venv/bin/activate   # (Windows: .venv\Scripts\activate)
pip install -r requirements.txt

# (Opcional) para aumentar cota do BlockCypher:
export BLOCKCYPHER_TOKEN="SEU_TOKEN_OPCIONAL"

# (Opcional) outras variáveis:
export DEFAULT_ADDRESS="1Xcdre9pAipV9kiSrSgssEpQPAruzMFzr"
export PORT=8000
export DEBUG=true

python server.py
# Abra http://localhost:8000
```

## Segurança
- **Não** informe WIF/seed no navegador. Gere e **assine a PSBT em hardware wallet**.
- Este dashboard aceita o **HEX final** para broadcast e verificação de confirmações.

## Migração gradual
- Você pode mover componentes do legacy/ para a raiz conforme verificar compatibilidade.
- Caso deseje, posso adaptar os módulos originais (`dashboard_data.py`, `api_integrations.py`, etc.) para
  consumir diretamente os endpoints deste backend unificado.


*Atualização v5*: adicionado PSBT Builder no frontend e endpoint `/api/rawtx/<txid>` para permitir construção segura de PSBTs com nonWitnessUtxo via Blockstream.
