
import os
import json
import logging
from urllib.parse import urlencode

import requests
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# ---------- Config ----------
BLOCKSTREAM_API = os.environ.get("BLOCKSTREAM_API", "https://blockstream.info/api")
BLOCKCYPHER_API = os.environ.get("BLOCKCYPHER_API", "https://api.blockcypher.com/v1/btc/main")
BLOCKCYPHER_TOKEN = os.environ.get("BLOCKCYPHER_TOKEN")
DEFAULT_ADDRESS = os.environ.get("DEFAULT_ADDRESS", "1Xcdre9pAipV9kiSrSgssEpQPAruzMFzr")
PORT = int(os.environ.get("PORT", "8000"))
DEBUG = os.environ.get("DEBUG", "false").lower() == "true"

app = Flask(__name__, static_folder="static", static_url_path="/static")
CORS(app)

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("pesbm")

# ---------- Helpers ----------
def _ok(data, status=200):
    return jsonify({"ok": True, "data": data}), status

def _err(message, status=400):
    return jsonify({"ok": False, "error": str(message)}), status

def _blockstream_get(path):
    url = f"{BLOCKSTREAM_API.rstrip('/')}/{path.lstrip('/')}"
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    return r.json()

# ---------- Routes ----------
@app.route("/")
def root():
    return send_from_directory("static", "index.html")

@app.route("/api/health")
def health():
    return _ok({"status": "up", "default_address": DEFAULT_ADDRESS})

@app.route("/api/address/<addr>")
def address_info(addr):
    try:
        # chain stats & mempool stats
        data = _blockstream_get(f"address/{addr}")
        # utxos (confirmed only by default)
        utxos = _blockstream_get(f"address/{addr}/utxo")
        data["utxos"] = utxos
        # computed balance (confirmed)
        funded = data.get("chain_stats", {}).get("funded_txo_sum", 0)
        spent = data.get("chain_stats", {}).get("spent_txo_sum", 0)
        balance_sat = int(funded) - int(spent)
        data["balance_sat"] = balance_sat
        data["balance_btc"] = balance_sat / 1e8
        return _ok(data)
    except requests.HTTPError as e:
        return _err(f"Blockstream error: {e.response.text}", e.response.status_code if e.response is not None else 502)
    except Exception as e:
        return _err(f"Unexpected: {e}", 500)

@app.route("/api/pesbm/status")
def tx_status():
    txid = request.args.get("txid")
    if not txid:
        return _err("Parâmetro 'txid' é obrigatório", 400)
    try:
        tx = _blockstream_get(f"tx/{txid}")
        confs = tx.get("status", {}).get("confirmations", 0) or 0
        confirmed = bool(tx.get("status", {}).get("confirmed", False))
        return _ok({"txid": txid, "confirmations": confs, "confirmed": confirmed, "block_height": tx.get("status", {}).get("block_height")})
    except requests.HTTPError as e:
        return _err(f"Blockstream error: {e.response.text}", e.response.status_code if e.response is not None else 502)
    except Exception as e:
        return _err(f"Unexpected: {e}", 500)

@app.route("/api/pesbm/broadcast", methods=["POST"])
def broadcast_hex():
    payload = request.get_json(silent=True) or {}
    hex_tx = payload.get("hex")
    if not hex_tx or not isinstance(hex_tx, str):
        return _err("Campo 'hex' (string) é obrigatório", 400)

    # Try Blockstream first
    try:
        url = f"{BLOCKSTREAM_API.rstrip('/')}/tx"
        r = requests.post(url, data=hex_tx, timeout=30, headers={"Content-Type": "text/plain"})
        r.raise_for_status()
        txid = r.text.strip().replace('"', '')
        return _ok({"txid": txid, "provider": "blockstream"})
    except Exception as e:
        log.warning("Blockstream broadcast falhou, tentando BlockCypher... (%s)", e)

    # Fallback BlockCypher
    try:
        url = f"{BLOCKCYPHER_API.rstrip('/')}/txs/push"
        data = {"tx": hex_tx}
        if BLOCKCYPHER_TOKEN:
            url += f"?token={BLOCKCYPHER_TOKEN}"
        r = requests.post(url, json=data, timeout=30)
        r.raise_for_status()
        j = r.json()
        tx_hash = j.get("tx", {}).get("hash") or j.get("tx", {}).get("hashes") or j.get("tx", {}).get("tx", {}).get("hash")
        return _ok({"txid": tx_hash, "provider": "blockcypher"})
    except requests.HTTPError as e:
        try:
            return _err(f"BlockCypher error: {e.response.text}", e.response.status_code if e.response is not None else 502)
        except Exception:
            return _err("BlockCypher error", 502)
    except Exception as e:
        return _err(f"Broadcast falhou em todos os provedores: {e}", 502)

# ---------- Static files ----------
@app.route("/static/<path:path>")


@app.route("/api/rawtx/<txid>")
def rawtx(txid):
    \"\"\"Return raw tx hex for txid via Blockstream proxy.\"\"\"
    try:
        # Blockstream provides /tx/:txid/hex
        url = f"{BLOCKSTREAM_API.rstrip('/')}/tx/{txid}/hex"
        r = requests.get(url, timeout=30)
        r.raise_for_status()
        hexstr = r.text.strip().replace('\"','')
        return _ok({"txid": txid, "hex": hexstr})
    except requests.HTTPError as e:
        return _err(f\"Blockstream error: {e.response.text}\", e.response.status_code if e.response is not None else 502)
    except Exception as e:
        return _err(f\"Unexpected: {e}\", 500)
def serve_static(path):
    return send_from_directory("static", path)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT, debug=DEBUG)
