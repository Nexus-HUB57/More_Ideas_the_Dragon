
"""
PESBM Dashboard (v3 - Public Node Edition)
- NENHUM uso de Bitcoin Core RPC.
- Consultas em tempo real via exploradores públicos (Blockstream / BlockCypher).
- Broadcast de transação via Blockstream (POST /tx), com fallback para BlockCypher (se token disponível).
- PSBT/assinatura acontece no FRONTEND usando bitcoinjs-lib (chave WIF fornecida pelo usuário, opcional).
  *Recomendado usar hardware wallet e importar a TX assinada como HEX, quando possível.*
"""

from flask import Flask, request, jsonify, send_from_directory
import requests, os

app = Flask(__name__, static_folder="static")

BLOCKSTREAM = "https://blockstream.info/api"
BLOCKCYPHER = "https://api.blockcypher.com/v1/btc/main"
BCYPH_TOKEN = os.getenv("BLOCKCYPHER_TOKEN")  # opcional

# --------- Address info (saldo em tempo real) ---------
@app.get("/api/address/<addr>")
def address_info(addr):
    try:
        ai = requests.get(f"{BLOCKSTREAM}/address/{addr}", timeout=30).json()
        utxos = requests.get(f"{BLOCKSTREAM}/address/{addr}/utxo", timeout=30).json()
        chain = ai.get("chain_stats", {})
        mempool = ai.get("mempool_stats", {})
        funded = (chain.get("funded_txo_sum", 0) or 0) + (mempool.get("funded_txo_sum", 0) or 0)
        spent  = (chain.get("spent_txo_sum", 0) or 0)  + (mempool.get("spent_txo_sum", 0) or 0)
        balance_sat = funded - spent
        return jsonify({
            "address": addr,
            "tx_count": (chain.get("tx_count", 0) or 0),
            "funded_txo_sum_sat": funded,
            "spent_txo_sum_sat": spent,
            "balance_sat": balance_sat,
            "balance_btc": balance_sat / 1e8,
            "utxos": utxos
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --------- TX status (confirmações) ---------
@app.get("/api/pesbm/status")
def pesbm_status():
    txid = request.args.get("txid")
    if not txid:
        return jsonify({"error": "missing txid"}), 400
    try:
        st = requests.get(f"{BLOCKSTREAM}/tx/{txid}/status", timeout=30).json()
        if st.get("confirmed"):
            tx = requests.get(f"{BLOCKSTREAM}/tx/{txid}", timeout=30).json()
            tip = int(requests.get(f"{BLOCKSTREAM}/blocks/tip/height", timeout=30).text)
            confs = tip - int(tx.get("status", {}).get("block_height", 0)) + 1
            st["confirmations"] = max(confs, 0)
        else:
            st["confirmations"] = 0
        return jsonify(st)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --------- Broadcast (via Blockstream; fallback BlockCypher) ---------
@app.post("/api/pesbm/broadcast")
def broadcast_hex():
    body = request.get_json(force=True)
    hex_tx = body.get("hex")
    if not hex_tx:
        return jsonify({"error":"missing hex"}), 400
    # 1) Blockstream
    try:
        r = requests.post(f"{BLOCKSTREAM}/tx", data=hex_tx, timeout=30, headers={"Content-Type":"text/plain"})
        if r.ok:
            return jsonify({"txid": r.text.strip(), "via": "blockstream"})
        bs_err = r.text
    except Exception as e:
        bs_err = str(e)

    # 2) BlockCypher (se token disponível, melhora quota; sem token, tenta anônimo)
    try:
        params = {"token": BCYPH_TOKEN} if BCYPH_TOKEN else {}
        r = requests.post(f"{BLOCKCYPHER}/txs/push", json={"tx": hex_tx}, params=params, timeout=30)
        if r.ok:
            j = r.json()
            tx = j.get("tx", {}) or j
            tx_hash = tx.get("hash") or tx.get("tx", {}).get("hash") or "unknown"
            return jsonify({"txid": tx_hash, "via": "blockcypher", "raw": j})
        bc_err = r.text
    except Exception as e:
        bc_err = str(e)

    return jsonify({"error": "broadcast failed", "blockstream_error": bs_err, "blockcypher_error": bc_err}), 502

# --------- Servir UI ---------
@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")

@app.get("/<path:path>")
def static_proxy(path):
    return send_from_directory(app.static_folder, path)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
