"""
Sistema de Monitoramento de Blocos Bitcoin em Tempo Real
Criado por Satoshi Nakamoto para o Dashboard Quântico
Monitora blocos da mainnet antes de qualquer transação
"""

from flask import Blueprint, jsonify, request
import json
import requests
import time
import threading
from datetime import datetime, timedelta
import logging
from .security_manager import security_manager

# Configuração do blueprint
realtime_bp = Blueprint('realtime', __name__, url_prefix='/api/realtime')

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RealtimeBlockMonitor:
    """Monitor de blocos Bitcoin em tempo real"""
    
    def __init__(self):
        self.current_block = None
        self.last_update = None
        self.monitoring = False
        self.monitor_thread = None
        self.block_apis = [
            "https://blockstream.info/api",
            "https://blockchain.info",
            "https://api.blockcypher.com/v1/btc/main"
        ]
        
        # Dados do bloco de referência fornecido
        self.reference_block = {
            "height": 910859,
            "hash": "00000000000000000004416ca",
            "time": "2025-08-20T06:09:02Z",
            "mined_date": "20 de agosto de 2025 06:09:02",
            "transactions": 3063,
            "size": 1563980,
            "weight": 3993923,
            "difficulty": 129435235580344.81,
            "nonce": 1653632356,
            "merkle_root": "48-8b",
            "version": "0x2c3dc000",
            "confirmations": 237,
            "total_btc": 2732.5623,
            "fees": 0.03022514,
            "reward": 3.15522514,
            "miner": "SpiderPool"
        }
        
        # Inicializa com o bloco de referência
        self.current_block = self.reference_block.copy()
        self.last_update = datetime.now()
    
    def get_latest_block_blockstream(self):
        """Obtém último bloco via Blockstream API"""
        try:
            response = requests.get(f"{self.block_apis[0]}/blocks/tip/height", timeout=10)
            if response.status_code == 200:
                height = int(response.text)
                
                # Obtém detalhes do bloco
                block_response = requests.get(f"{self.block_apis[0]}/block-height/{height}", timeout=10)
                if block_response.status_code == 200:
                    block_hash = block_response.text.strip()
                    
                    # Obtém dados completos do bloco
                    details_response = requests.get(f"{self.block_apis[0]}/block/{block_hash}", timeout=10)
                    if details_response.status_code == 200:
                        block_data = details_response.json()
                        
                        return {
                            "status": "success",
                            "source": "blockstream",
                            "block": {
                                "height": block_data.get("height"),
                                "hash": block_data.get("id"),
                                "time": datetime.fromtimestamp(block_data.get("timestamp", 0)).isoformat() + "Z",
                                "transactions": block_data.get("tx_count", 0),
                                "size": block_data.get("size", 0),
                                "weight": block_data.get("weight", 0),
                                "difficulty": block_data.get("difficulty"),
                                "nonce": block_data.get("nonce"),
                                "merkle_root": block_data.get("merkle_root"),
                                "version": hex(block_data.get("version", 0)),
                                "confirmations": 1,  # Último bloco sempre tem 1 confirmação inicial
                                "previous_block": block_data.get("previousblockhash"),
                                "bits": block_data.get("bits")
                            }
                        }
            
            return {"status": "error", "message": "Falha na API Blockstream"}
            
        except Exception as e:
            logger.error(f"Erro ao obter bloco via Blockstream: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def get_latest_block_blockchain_info(self):
        """Obtém último bloco via Blockchain.info API"""
        try:
            response = requests.get(f"{self.block_apis[1]}/latestblock", timeout=10)
            if response.status_code == 200:
                block_data = response.json()
                
                return {
                    "status": "success",
                    "source": "blockchain.info",
                    "block": {
                        "height": block_data.get("height"),
                        "hash": block_data.get("hash"),
                        "time": datetime.fromtimestamp(block_data.get("time", 0)).isoformat() + "Z",
                        "transactions": block_data.get("n_tx", 0),
                        "size": block_data.get("size", 0),
                        "weight": block_data.get("weight", 0),
                        "difficulty": block_data.get("difficulty"),
                        "nonce": block_data.get("nonce"),
                        "merkle_root": block_data.get("mrkl_root"),
                        "version": block_data.get("ver"),
                        "confirmations": 1,
                        "previous_block": block_data.get("prev_block"),
                        "bits": block_data.get("bits")
                    }
                }
            
            return {"status": "error", "message": "Falha na API Blockchain.info"}
            
        except Exception as e:
            logger.error(f"Erro ao obter bloco via Blockchain.info: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def get_latest_block_blockcypher(self):
        """Obtém último bloco via Blockcypher API"""
        try:
            response = requests.get(f"{self.block_apis[2]}", timeout=10)
            if response.status_code == 200:
                chain_data = response.json()
                height = chain_data.get("height")
                
                # Obtém detalhes do último bloco
                block_response = requests.get(f"{self.block_apis[2]}/blocks/{height}", timeout=10)
                if block_response.status_code == 200:
                    block_data = block_response.json()
                    
                    return {
                        "status": "success",
                        "source": "blockcypher",
                        "block": {
                            "height": block_data.get("height"),
                            "hash": block_data.get("hash"),
                            "time": block_data.get("time"),
                            "transactions": block_data.get("n_tx", 0),
                            "size": block_data.get("size", 0),
                            "weight": block_data.get("weight", 0),
                            "difficulty": block_data.get("difficulty"),
                            "nonce": block_data.get("nonce"),
                            "merkle_root": block_data.get("mrkl_root"),
                            "version": block_data.get("ver"),
                            "confirmations": 1,
                            "previous_block": block_data.get("prev_block"),
                            "bits": block_data.get("bits")
                        }
                    }
            
            return {"status": "error", "message": "Falha na API Blockcypher"}
            
        except Exception as e:
            logger.error(f"Erro ao obter bloco via Blockcypher: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def get_latest_block(self):
        """Obtém último bloco usando múltiplas APIs com fallback"""
        apis = [
            self.get_latest_block_blockstream,
            self.get_latest_block_blockchain_info,
            self.get_latest_block_blockcypher
        ]
        
        for api_func in apis:
            try:
                result = api_func()
                if result["status"] == "success":
                    return result
            except Exception as e:
                logger.error(f"Erro em API: {str(e)}")
                continue
        
        return {"status": "error", "message": "Todas as APIs falharam"}
    
    def update_current_block(self):
        """Atualiza o bloco atual"""
        try:
            result = self.get_latest_block()
            
            if result["status"] == "success":
                new_block = result["block"]
                
                # Verifica se é um novo bloco
                if (not self.current_block or 
                    new_block["height"] > self.current_block.get("height", 0)):
                    
                    logger.info(f"Novo bloco detectado: {new_block['height']}")
                    
                    # Adiciona informações calculadas
                    new_block["source"] = result["source"]
                    new_block["updated_at"] = datetime.now().isoformat()
                    new_block["is_new"] = True
                    
                    # Calcula tempo desde último bloco
                    if self.current_block and "time" in self.current_block:
                        try:
                            current_time = datetime.fromisoformat(new_block["time"].replace("Z", ""))
                            previous_time = datetime.fromisoformat(self.current_block["time"].replace("Z", ""))
                            time_diff = current_time - previous_time
                            new_block["time_since_previous"] = str(time_diff)
                        except:
                            new_block["time_since_previous"] = "unknown"
                    
                    self.current_block = new_block
                    self.last_update = datetime.now()
                    
                    return {"status": "success", "new_block": True, "block": new_block}
                else:
                    # Mesmo bloco, apenas atualiza timestamp
                    if self.current_block:
                        self.current_block["last_checked"] = datetime.now().isoformat()
                    
                    return {"status": "success", "new_block": False, "block": self.current_block}
            else:
                return result
                
        except Exception as e:
            logger.error(f"Erro ao atualizar bloco atual: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def start_monitoring(self, interval=30):
        """Inicia monitoramento contínuo de blocos"""
        if self.monitoring:
            return {"status": "error", "message": "Monitoramento já ativo"}
        
        self.monitoring = True
        
        def monitor_loop():
            logger.info("Iniciando monitoramento de blocos em tempo real")
            while self.monitoring:
                try:
                    self.update_current_block()
                    time.sleep(interval)
                except Exception as e:
                    logger.error(f"Erro no loop de monitoramento: {str(e)}")
                    time.sleep(interval)
        
        self.monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
        self.monitor_thread.start()
        
        return {"status": "success", "message": f"Monitoramento iniciado (intervalo: {interval}s)"}
    
    def stop_monitoring(self):
        """Para o monitoramento de blocos"""
        if not self.monitoring:
            return {"status": "error", "message": "Monitoramento não está ativo"}
        
        self.monitoring = False
        logger.info("Monitoramento de blocos parado")
        
        return {"status": "success", "message": "Monitoramento parado"}
    
    def validate_block_for_transaction(self, min_confirmations=1):
        """Valida se o bloco atual é adequado para transações"""
        if not self.current_block:
            return {
                "status": "error", 
                "message": "Nenhum bloco atual disponível",
                "safe_to_transact": False
            }
        
        # Verifica se os dados são recentes (menos de 5 minutos)
        if self.last_update:
            time_diff = datetime.now() - self.last_update
            if time_diff > timedelta(minutes=5):
                return {
                    "status": "warning",
                    "message": "Dados do bloco podem estar desatualizados",
                    "safe_to_transact": False,
                    "last_update": self.last_update.isoformat()
                }
        
        # Verifica altura mínima do bloco
        current_height = self.current_block.get("height", 0)
        if current_height < 910859:  # Altura de referência
            return {
                "status": "error",
                "message": f"Altura do bloco muito baixa: {current_height}",
                "safe_to_transact": False
            }
        
        # Validação passou
        return {
            "status": "success",
            "message": "Bloco validado para transações",
            "safe_to_transact": True,
            "current_block": self.current_block,
            "validation_time": datetime.now().isoformat()
        }
    
    def get_network_health(self):
        """Obtém saúde geral da rede Bitcoin"""
        try:
            # Tenta obter dados de múltiplas fontes
            health_data = {
                "timestamp": datetime.now().isoformat(),
                "current_block": self.current_block,
                "last_update": self.last_update.isoformat() if self.last_update else None,
                "monitoring_active": self.monitoring,
                "network_status": "unknown"
            }
            
            if self.current_block:
                # Calcula estatísticas da rede
                current_height = self.current_block.get("height", 0)
                
                # Verifica se está sincronizado (altura deve ser recente)
                expected_min_height = 910859  # Altura de referência
                
                if current_height >= expected_min_height:
                    health_data["network_status"] = "healthy"
                    health_data["sync_status"] = "synchronized"
                else:
                    health_data["network_status"] = "warning"
                    health_data["sync_status"] = "behind"
                
                health_data["height_difference"] = current_height - expected_min_height
                
                # Adiciona informações de tempo
                if "time" in self.current_block:
                    try:
                        block_time = datetime.fromisoformat(self.current_block["time"].replace("Z", ""))
                        time_diff = datetime.now() - block_time
                        health_data["block_age_minutes"] = time_diff.total_seconds() / 60
                        
                        # Se o bloco é muito antigo, marca como problema
                        if time_diff > timedelta(hours=1):
                            health_data["network_status"] = "warning"
                            health_data["warning"] = "Último bloco muito antigo"
                    except:
                        pass
            
            return {
                "status": "success",
                "health": health_data
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter saúde da rede: {str(e)}")
            return {"status": "error", "message": str(e)}

# Instância global do monitor
block_monitor = RealtimeBlockMonitor()

# Inicia monitoramento automaticamente
block_monitor.start_monitoring(interval=15)  # Verifica a cada 15 segundos

# Rotas da API

@realtime_bp.route('/current-block', methods=['GET'])
def get_current_block():
    """Endpoint para obter bloco atual"""
    if not block_monitor.current_block:
        return jsonify({"error": "Nenhum bloco disponível"}), 404
    
    return jsonify({
        "status": "success",
        "block": block_monitor.current_block,
        "last_update": block_monitor.last_update.isoformat() if block_monitor.last_update else None
    })

@realtime_bp.route('/update-block', methods=['POST'])
def force_update_block():
    """Endpoint para forçar atualização do bloco"""
    result = block_monitor.update_current_block()
    return jsonify(result)

@realtime_bp.route('/validate-for-transaction', methods=['GET'])
def validate_for_transaction():
    """Endpoint para validar se é seguro fazer transações"""
    min_confirmations = request.args.get('min_confirmations', 1, type=int)
    result = block_monitor.validate_block_for_transaction(min_confirmations)
    return jsonify(result)

@realtime_bp.route('/network-health', methods=['GET'])
def get_network_health():
    """Endpoint para obter saúde da rede"""
    result = block_monitor.get_network_health()
    return jsonify(result)

@realtime_bp.route('/monitoring/start', methods=['POST'])
def start_monitoring():
    """Endpoint para iniciar monitoramento"""
    data = request.get_json() or {}
    interval = data.get('interval', 30)
    result = block_monitor.start_monitoring(interval)
    return jsonify(result)

@realtime_bp.route('/monitoring/stop', methods=['POST'])
def stop_monitoring():
    """Endpoint para parar monitoramento"""
    result = block_monitor.stop_monitoring()
    return jsonify(result)

@realtime_bp.route('/monitoring/status', methods=['GET'])
def get_monitoring_status():
    """Endpoint para obter status do monitoramento"""
    return jsonify({
        "status": "success",
        "monitoring_active": block_monitor.monitoring,
        "current_block_height": block_monitor.current_block.get("height") if block_monitor.current_block else None,
        "last_update": block_monitor.last_update.isoformat() if block_monitor.last_update else None,
        "reference_block": block_monitor.reference_block
    })

@realtime_bp.route('/block-history', methods=['GET'])
def get_block_history():
    """Endpoint para obter histórico de blocos recentes"""
    try:
        limit = request.args.get('limit', 10, type=int)
        
        # Obtém blocos recentes via API
        current_height = block_monitor.current_block.get("height", 910859) if block_monitor.current_block else 910859
        
        blocks = []
        for i in range(limit):
            height = current_height - i
            if height < 0:
                break
                
            try:
                # Tenta obter dados do bloco
                response = requests.get(f"https://blockstream.info/api/block-height/{height}", timeout=5)
                if response.status_code == 200:
                    block_hash = response.text.strip()
                    
                    details_response = requests.get(f"https://blockstream.info/api/block/{block_hash}", timeout=5)
                    if details_response.status_code == 200:
                        block_data = details_response.json()
                        
                        blocks.append({
                            "height": height,
                            "hash": block_data.get("id"),
                            "time": datetime.fromtimestamp(block_data.get("timestamp", 0)).isoformat(),
                            "transactions": block_data.get("tx_count", 0),
                            "size": block_data.get("size", 0)
                        })
            except:
                # Se falhar, adiciona dados básicos
                blocks.append({
                    "height": height,
                    "hash": "unavailable",
                    "time": "unknown",
                    "transactions": 0,
                    "size": 0
                })
        
        return jsonify({
            "status": "success",
            "blocks": blocks,
            "current_height": current_height
        })
        
    except Exception as e:
        logger.error(f"Erro ao obter histórico de blocos: {str(e)}")
        return jsonify({"error": str(e)}), 500

# Middleware para validar bloco antes de transações
def validate_block_before_transaction():
    """Middleware para validar bloco antes de qualquer transação"""
    validation = block_monitor.validate_block_for_transaction()
    
    if not validation.get("safe_to_transact", False):
        return {
            "status": "error",
            "message": "Transação bloqueada: " + validation.get("message", "Bloco não validado"),
            "validation": validation
        }
    
    return {"status": "success", "validation": validation}

