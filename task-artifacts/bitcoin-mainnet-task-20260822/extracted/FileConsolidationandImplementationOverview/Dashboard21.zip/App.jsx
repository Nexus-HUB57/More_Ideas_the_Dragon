Inherited file content will not be shown
