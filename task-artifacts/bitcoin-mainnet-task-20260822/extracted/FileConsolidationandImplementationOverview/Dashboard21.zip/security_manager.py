"""
Sistema de Segurança Criptográfica para Wallets
Criado por Satoshi Nakamoto para o Dashboard Quântico
Implementa Master Key protegida por passphrase "Benjamin2020*1981$"
"""

from flask import Blueprint, jsonify, request
import json
import os
import hashlib
import hmac
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
import secrets
import time
from datetime import datetime
import logging
import bitcoin
from ecdsa import SigningKey, SECP256k1
import binascii

# Configuração do blueprint
security_bp = Blueprint('security', __name__, url_prefix='/api/security')

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Passphrase mestra conforme especificação
MASTER_PASSPHRASE = "Benjamin2020*1981$"

class QuantumSecurityManager:
    """Gerenciador de segurança quântica para wallets"""
    
    def __init__(self, data_dir="/home/ubuntu/quantum_dashboard/data"):
        self.data_dir = data_dir
        self.private_keys_file = os.path.join(data_dir, "private_keys_database.json")
        self.master_key_file = os.path.join(data_dir, "master_key.enc")
        self.salt_file = os.path.join(data_dir, "security.salt")
        
        # Garante que o diretório existe
        os.makedirs(data_dir, exist_ok=True)
        
        # Inicializa ou carrega a master key
        self._initialize_master_key()
    
    def _generate_salt(self):
        """Gera um salt criptográfico seguro"""
        return secrets.token_bytes(32)
    
    def _derive_key_from_passphrase(self, passphrase, salt):
        """Deriva uma chave criptográfica da passphrase usando PBKDF2"""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
            backend=default_backend()
        )
        key = base64.urlsafe_b64encode(kdf.derive(passphrase.encode()))
        return key
    
    def _initialize_master_key(self):
        """Inicializa ou carrega a master key"""
        try:
            # Verifica se já existe salt
            if os.path.exists(self.salt_file):
                with open(self.salt_file, 'rb') as f:
                    salt = f.read()
            else:
                # Gera novo salt
                salt = self._generate_salt()
                with open(self.salt_file, 'wb') as f:
                    f.write(salt)
            
            # Deriva a master key da passphrase
            self.master_key = self._derive_key_from_passphrase(MASTER_PASSPHRASE, salt)
            self.fernet = Fernet(self.master_key)
            
            # Verifica se existe arquivo de master key criptografado
            if not os.path.exists(self.master_key_file):
                # Cria um identificador único para a master key
                master_key_id = secrets.token_hex(16)
                encrypted_id = self.fernet.encrypt(master_key_id.encode())
                
                with open(self.master_key_file, 'wb') as f:
                    f.write(encrypted_id)
                
                logger.info("Master Key inicializada com sucesso")
            else:
                # Verifica se a master key pode ser descriptografada
                with open(self.master_key_file, 'rb') as f:
                    encrypted_id = f.read()
                
                try:
                    decrypted_id = self.fernet.decrypt(encrypted_id)
                    logger.info("Master Key carregada com sucesso")
                except Exception as e:
                    logger.error(f"Erro ao carregar Master Key: {str(e)}")
                    raise Exception("Passphrase incorreta ou arquivo corrompido")
                    
        except Exception as e:
            logger.error(f"Erro ao inicializar Master Key: {str(e)}")
            raise
    
    def encrypt_private_key(self, private_key, wallet_address):
        """Criptografa uma chave privada"""
        try:
            # Cria um objeto com metadados
            key_data = {
                "private_key": private_key,
                "wallet_address": wallet_address,
                "encrypted_at": datetime.now().isoformat(),
                "key_type": "bitcoin_private_key"
            }
            
            # Converte para JSON e criptografa
            json_data = json.dumps(key_data)
            encrypted_data = self.fernet.encrypt(json_data.encode())
            
            return {
                "status": "success",
                "encrypted_key": base64.b64encode(encrypted_data).decode(),
                "wallet_address": wallet_address
            }
            
        except Exception as e:
            logger.error(f"Erro ao criptografar chave privada: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def decrypt_private_key(self, encrypted_key_b64):
        """Descriptografa uma chave privada"""
        try:
            # Decodifica base64 e descriptografa
            encrypted_data = base64.b64decode(encrypted_key_b64)
            decrypted_json = self.fernet.decrypt(encrypted_data)
            key_data = json.loads(decrypted_json.decode())
            
            return {
                "status": "success",
                "private_key": key_data["private_key"],
                "wallet_address": key_data["wallet_address"],
                "encrypted_at": key_data.get("encrypted_at"),
                "key_type": key_data.get("key_type")
            }
            
        except Exception as e:
            logger.error(f"Erro ao descriptografar chave privada: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def store_wallet(self, private_key, wallet_address=None):
        """Armazena uma carteira no banco de dados criptografado"""
        try:
            # Se não foi fornecido endereço, deriva da chave privada
            if not wallet_address:
                try:
                    # Converte chave privada para formato correto se necessário
                    if private_key.startswith('0x'):
                        private_key = private_key[2:]
                    
                    # Deriva o endereço público da chave privada
                    wallet_address = bitcoin.privkey_to_address(private_key)
                    
                except Exception as e:
                    logger.error(f"Erro ao derivar endereço: {str(e)}")
                    return {"status": "error", "message": f"Erro ao derivar endereço: {str(e)}"}
            
            # Criptografa a chave privada
            encryption_result = self.encrypt_private_key(private_key, wallet_address)
            
            if encryption_result["status"] != "success":
                return encryption_result
            
            # Carrega o banco de dados existente
            wallets_db = self._load_wallets_database()
            
            # Adiciona a nova carteira
            wallet_id = secrets.token_hex(8)
            wallets_db["wallets"][wallet_id] = {
                "wallet_address": wallet_address,
                "encrypted_private_key": encryption_result["encrypted_key"],
                "created_at": datetime.now().isoformat(),
                "last_accessed": datetime.now().isoformat(),
                "status": "active"
            }
            
            # Atualiza metadados
            wallets_db["metadata"]["total_wallets"] = len(wallets_db["wallets"])
            wallets_db["metadata"]["last_updated"] = datetime.now().isoformat()
            
            # Salva o banco de dados
            save_result = self._save_wallets_database(wallets_db)
            
            if save_result["status"] == "success":
                return {
                    "status": "success",
                    "wallet_id": wallet_id,
                    "wallet_address": wallet_address,
                    "message": "Carteira armazenada com sucesso"
                }
            else:
                return save_result
                
        except Exception as e:
            logger.error(f"Erro ao armazenar carteira: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def get_wallet(self, wallet_id):
        """Recupera uma carteira do banco de dados"""
        try:
            wallets_db = self._load_wallets_database()
            
            if wallet_id not in wallets_db["wallets"]:
                return {"status": "error", "message": "Carteira não encontrada"}
            
            wallet_data = wallets_db["wallets"][wallet_id]
            
            # Descriptografa a chave privada
            decryption_result = self.decrypt_private_key(wallet_data["encrypted_private_key"])
            
            if decryption_result["status"] != "success":
                return decryption_result
            
            # Atualiza último acesso
            wallets_db["wallets"][wallet_id]["last_accessed"] = datetime.now().isoformat()
            self._save_wallets_database(wallets_db)
            
            return {
                "status": "success",
                "wallet_id": wallet_id,
                "wallet_address": wallet_data["wallet_address"],
                "private_key": decryption_result["private_key"],
                "created_at": wallet_data["created_at"],
                "last_accessed": wallet_data["last_accessed"]
            }
            
        except Exception as e:
            logger.error(f"Erro ao recuperar carteira: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def list_wallets(self):
        """Lista todas as carteiras (sem chaves privadas)"""
        try:
            wallets_db = self._load_wallets_database()
            
            wallets_list = []
            for wallet_id, wallet_data in wallets_db["wallets"].items():
                wallets_list.append({
                    "wallet_id": wallet_id,
                    "wallet_address": wallet_data["wallet_address"],
                    "created_at": wallet_data["created_at"],
                    "last_accessed": wallet_data["last_accessed"],
                    "status": wallet_data["status"]
                })
            
            return {
                "status": "success",
                "wallets": wallets_list,
                "total_wallets": len(wallets_list),
                "metadata": wallets_db["metadata"]
            }
            
        except Exception as e:
            logger.error(f"Erro ao listar carteiras: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def delete_wallet(self, wallet_id):
        """Remove uma carteira do banco de dados"""
        try:
            wallets_db = self._load_wallets_database()
            
            if wallet_id not in wallets_db["wallets"]:
                return {"status": "error", "message": "Carteira não encontrada"}
            
            # Remove a carteira
            deleted_wallet = wallets_db["wallets"].pop(wallet_id)
            
            # Atualiza metadados
            wallets_db["metadata"]["total_wallets"] = len(wallets_db["wallets"])
            wallets_db["metadata"]["last_updated"] = datetime.now().isoformat()
            
            # Salva o banco de dados
            save_result = self._save_wallets_database(wallets_db)
            
            if save_result["status"] == "success":
                return {
                    "status": "success",
                    "message": "Carteira removida com sucesso",
                    "deleted_address": deleted_wallet["wallet_address"]
                }
            else:
                return save_result
                
        except Exception as e:
            logger.error(f"Erro ao remover carteira: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def _load_wallets_database(self):
        """Carrega o banco de dados de carteiras"""
        try:
            if os.path.exists(self.private_keys_file):
                with open(self.private_keys_file, 'r') as f:
                    return json.load(f)
            else:
                # Cria estrutura inicial
                return {
                    "metadata": {
                        "created_at": datetime.now().isoformat(),
                        "last_updated": datetime.now().isoformat(),
                        "total_wallets": 0,
                        "version": "1.0",
                        "encryption": "AES-256-Fernet"
                    },
                    "wallets": {}
                }
        except Exception as e:
            logger.error(f"Erro ao carregar banco de dados: {str(e)}")
            raise
    
    def _save_wallets_database(self, wallets_db):
        """Salva o banco de dados de carteiras"""
        try:
            with open(self.private_keys_file, 'w') as f:
                json.dump(wallets_db, f, indent=2)
            
            return {"status": "success", "message": "Banco de dados salvo"}
            
        except Exception as e:
            logger.error(f"Erro ao salvar banco de dados: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def sign_transaction(self, wallet_id, transaction_data):
        """Assina uma transação usando a chave privada da carteira"""
        try:
            # Recupera a carteira
            wallet_result = self.get_wallet(wallet_id)
            
            if wallet_result["status"] != "success":
                return wallet_result
            
            private_key = wallet_result["private_key"]
            
            # Implementa assinatura real da transação Bitcoin
            import bitcoin
            from bitcoin import *
            
            # Configura para mainnet
            bitcoin.SelectParams('mainnet')
            
            # Assina os dados da transação
            tx_hash = transaction_data.get('tx_hash')
            if not tx_hash:
                # Gera hash da transação se não fornecido
                tx_hash = hashlib.sha256(json.dumps(transaction_data, sort_keys=True).encode()).hexdigest()
            
            # Assina com a chave privada usando ECDSA
            signature = bitcoin.ecdsa_sign(tx_hash, private_key)
            
            signature_data = {
                "wallet_id": wallet_id,
                "wallet_address": wallet_result["wallet_address"],
                "transaction_hash": tx_hash,
                "signed_at": datetime.now().isoformat(),
                "signature": signature,
                "public_key": bitcoin.privkey_to_pubkey(private_key)
            }
            
            return {
                "status": "success",
                "signature_data": signature_data,
                "message": "Transação assinada com sucesso na mainnet"
            }
            
        except Exception as e:
            logger.error(f"Erro ao assinar transação: {str(e)}")
            return {"status": "error", "message": str(e)}

# Instância global do gerenciador de segurança
security_manager = QuantumSecurityManager()

# Rotas da API

@security_bp.route('/store-wallet', methods=['POST'])
def store_wallet():
    """Endpoint para armazenar uma carteira"""
    try:
        data = request.get_json()
        private_key = data.get('private_key')
        wallet_address = data.get('wallet_address')
        
        if not private_key:
            return jsonify({"error": "Chave privada é obrigatória"}), 400
        
        result = security_manager.store_wallet(private_key, wallet_address)
        
        if result["status"] == "success":
            return jsonify(result)
        else:
            return jsonify(result), 400
            
    except Exception as e:
        logger.error(f"Erro no endpoint store-wallet: {str(e)}")
        return jsonify({"error": str(e)}), 500

@security_bp.route('/wallets', methods=['GET'])
def list_wallets():
    """Endpoint para listar carteiras"""
    try:
        result = security_manager.list_wallets()
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Erro no endpoint list-wallets: {str(e)}")
        return jsonify({"error": str(e)}), 500

@security_bp.route('/wallet/<wallet_id>', methods=['GET'])
def get_wallet(wallet_id):
    """Endpoint para recuperar uma carteira específica"""
    try:
        result = security_manager.get_wallet(wallet_id)
        
        if result["status"] == "success":
            # Remove a chave privada da resposta por segurança
            response_data = result.copy()
            response_data.pop("private_key", None)
            return jsonify(response_data)
        else:
            return jsonify(result), 404
            
    except Exception as e:
        logger.error(f"Erro no endpoint get-wallet: {str(e)}")
        return jsonify({"error": str(e)}), 500

@security_bp.route('/wallet/<wallet_id>/private-key', methods=['POST'])
def get_wallet_private_key(wallet_id):
    """Endpoint para recuperar chave privada (requer autenticação adicional)"""
    try:
        data = request.get_json()
        provided_passphrase = data.get('passphrase')
        
        # Verifica a passphrase mestra
        if provided_passphrase != MASTER_PASSPHRASE:
            return jsonify({"error": "Passphrase incorreta"}), 401
        
        result = security_manager.get_wallet(wallet_id)
        
        if result["status"] == "success":
            return jsonify({
                "status": "success",
                "wallet_id": wallet_id,
                "wallet_address": result["wallet_address"],
                "private_key": result["private_key"]
            })
        else:
            return jsonify(result), 404
            
    except Exception as e:
        logger.error(f"Erro no endpoint get-wallet-private-key: {str(e)}")
        return jsonify({"error": str(e)}), 500

@security_bp.route('/wallet/<wallet_id>', methods=['DELETE'])
def delete_wallet(wallet_id):
    """Endpoint para remover uma carteira"""
    try:
        data = request.get_json()
        provided_passphrase = data.get('passphrase')
        
        # Verifica a passphrase mestra
        if provided_passphrase != MASTER_PASSPHRASE:
            return jsonify({"error": "Passphrase incorreta"}), 401
        
        result = security_manager.delete_wallet(wallet_id)
        
        if result["status"] == "success":
            return jsonify(result)
        else:
            return jsonify(result), 404
            
    except Exception as e:
        logger.error(f"Erro no endpoint delete-wallet: {str(e)}")
        return jsonify({"error": str(e)}), 500

@security_bp.route('/sign-transaction', methods=['POST'])
def sign_transaction():
    """Endpoint para assinar uma transação"""
    try:
        data = request.get_json()
        wallet_id = data.get('wallet_id')
        transaction_data = data.get('transaction_data')
        provided_passphrase = data.get('passphrase')
        
        # Verifica a passphrase mestra
        if provided_passphrase != MASTER_PASSPHRASE:
            return jsonify({"error": "Passphrase incorreta"}), 401
        
        if not wallet_id or not transaction_data:
            return jsonify({"error": "wallet_id e transaction_data são obrigatórios"}), 400
        
        result = security_manager.sign_transaction(wallet_id, transaction_data)
        
        if result["status"] == "success":
            return jsonify(result)
        else:
            return jsonify(result), 400
            
    except Exception as e:
        logger.error(f"Erro no endpoint sign-transaction: {str(e)}")
        return jsonify({"error": str(e)}), 500

@security_bp.route('/health', methods=['GET'])
def security_health():
    """Endpoint para verificar saúde do sistema de segurança"""
    try:
        # Verifica se a master key está funcionando
        test_data = "test_encryption"
        encrypted = security_manager.fernet.encrypt(test_data.encode())
        decrypted = security_manager.fernet.decrypt(encrypted).decode()
        
        encryption_ok = (test_data == decrypted)
        
        # Verifica arquivos de segurança
        files_status = {
            "master_key_file": os.path.exists(security_manager.master_key_file),
            "salt_file": os.path.exists(security_manager.salt_file),
            "private_keys_database": os.path.exists(security_manager.private_keys_file)
        }
        
        # Carrega estatísticas do banco de dados
        wallets_db = security_manager._load_wallets_database()
        
        return jsonify({
            "status": "success",
            "timestamp": datetime.now().isoformat(),
            "encryption_test": encryption_ok,
            "files_status": files_status,
            "database_stats": {
                "total_wallets": wallets_db["metadata"]["total_wallets"],
                "last_updated": wallets_db["metadata"]["last_updated"],
                "version": wallets_db["metadata"]["version"]
            },
            "security_level": "quantum_grade"
        })
        
    except Exception as e:
        logger.error(f"Erro no endpoint security-health: {str(e)}")
        return jsonify({"error": str(e)}), 500

