"""
Módulo de Dados do Dashboard Quântico - Mainnet Real
Criado por Satoshi Nakamoto para o Dashboard Quântico
Fornece dados reais da mainnet Bitcoin exclusivamente
"""

from flask import Blueprint, jsonify, request
import json
import requests
from datetime import datetime, timedelta
import logging
from .security_manager import security_manager
from .mainnet_transactions import mainnet_manager
from .api_integrations import blockchain_integration, blockcypher_integration, binance_integration

# Configuração do blueprint
dashboard_bp = Blueprint('dashboard', __name__, url_prefix='/api/dashboard')

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class QuantumDashboardData:
    """Gerenciador de dados do dashboard quântico"""
    
    def __init__(self):
        self.custody_address = "13m3xop6RnioRX6qrnkavLekv7cvu5DuMK"
        self.expected_custody_balance = 31089.84355968  # BTC conforme relatório
    
    def get_portfolio_overview(self):
        """Obtém visão geral do portfólio na mainnet"""
        try:
            # Lista todas as carteiras
            wallets_result = security_manager.list_wallets()
            
            if wallets_result["status"] != "success":
                return {"status": "error", "message": "Erro ao obter carteiras"}
            
            portfolio_data = {
                "total_wallets": len(wallets_result["wallets"]),
                "wallets": [],
                "total_balance_btc": 0,
                "total_balance_usd": 0,
                "custody_wallet": None
            }
            
            # Obtém preço atual do Bitcoin
            btc_price = self._get_btc_price()
            
            # Processa cada carteira
            for wallet in wallets_result["wallets"]:
                wallet_id = wallet["wallet_id"]
                address = wallet["wallet_address"]
                
                # Obtém saldo real da mainnet
                balance_result = blockchain_integration.get_address_balance(address)
                
                if balance_result["status"] == "success":
                    balance_btc = balance_result["data"]["balance_btc"]
                    balance_usd = balance_btc * btc_price if btc_price else 0
                    
                    wallet_data = {
                        "wallet_id": wallet_id,
                        "address": address,
                        "balance_btc": balance_btc,
                        "balance_usd": balance_usd,
                        "created_at": wallet["created_at"],
                        "last_accessed": wallet["last_accessed"],
                        "status": wallet["status"]
                    }
                    
                    portfolio_data["wallets"].append(wallet_data)
                    portfolio_data["total_balance_btc"] += balance_btc
                    portfolio_data["total_balance_usd"] += balance_usd
                    
                    # Verifica se é a carteira de custódia
                    if address == self.custody_address:
                        portfolio_data["custody_wallet"] = wallet_data
            
            # Adiciona informações da carteira de custódia se não estiver nas carteiras gerenciadas
            if not portfolio_data["custody_wallet"]:
                custody_balance = blockchain_integration.get_address_balance(self.custody_address)
                if custody_balance["status"] == "success":
                    portfolio_data["custody_wallet"] = {
                        "address": self.custody_address,
                        "balance_btc": custody_balance["data"]["balance_btc"],
                        "balance_usd": custody_balance["data"]["balance_btc"] * btc_price if btc_price else 0,
                        "type": "custody",
                        "expected_balance": self.expected_custody_balance
                    }
            
            portfolio_data["btc_price_usd"] = btc_price
            portfolio_data["last_updated"] = datetime.now().isoformat()
            
            return {
                "status": "success",
                "portfolio": portfolio_data
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter visão geral do portfólio: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def get_recent_transactions(self, limit=20):
        """Obtém transações recentes de todas as carteiras"""
        try:
            wallets_result = security_manager.list_wallets()
            
            if wallets_result["status"] != "success":
                return {"status": "error", "message": "Erro ao obter carteiras"}
            
            all_transactions = []
            
            # Obtém transações de cada carteira
            for wallet in wallets_result["wallets"]:
                address = wallet["wallet_address"]
                
                # Obtém transações da mainnet
                tx_result = blockchain_integration.get_address_transactions(address, limit=10)
                
                if tx_result["status"] == "success":
                    transactions = tx_result["data"]["transactions"]
                    
                    for tx in transactions:
                        # Processa cada transação
                        processed_tx = {
                            "txid": tx.get("hash"),
                            "wallet_address": address,
                            "wallet_id": wallet["wallet_id"],
                            "time": tx.get("time", 0),
                            "block_height": tx.get("block_height"),
                            "fee": tx.get("fee", 0),
                            "size": tx.get("size", 0),
                            "inputs": len(tx.get("inputs", [])),
                            "outputs": len(tx.get("out", [])),
                            "value": 0,  # Será calculado
                            "type": "unknown"  # Será determinado
                        }
                        
                        # Calcula valor e tipo da transação
                        input_value = 0
                        output_value = 0
                        
                        # Verifica inputs
                        for inp in tx.get("inputs", []):
                            prev_out = inp.get("prev_out", {})
                            if prev_out.get("addr") == address:
                                input_value += prev_out.get("value", 0)
                        
                        # Verifica outputs
                        for out in tx.get("out", []):
                            if out.get("addr") == address:
                                output_value += out.get("value", 0)
                        
                        # Determina tipo e valor
                        if input_value > 0 and output_value == 0:
                            processed_tx["type"] = "sent"
                            processed_tx["value"] = -input_value
                        elif input_value == 0 and output_value > 0:
                            processed_tx["type"] = "received"
                            processed_tx["value"] = output_value
                        else:
                            processed_tx["type"] = "internal"
                            processed_tx["value"] = output_value - input_value
                        
                        processed_tx["value_btc"] = processed_tx["value"] / 100000000
                        
                        all_transactions.append(processed_tx)
            
            # Ordena por tempo (mais recentes primeiro)
            all_transactions.sort(key=lambda x: x["time"], reverse=True)
            
            return {
                "status": "success",
                "transactions": all_transactions[:limit],
                "total_found": len(all_transactions)
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter transações recentes: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def get_network_stats(self):
        """Obtém estatísticas da rede Bitcoin"""
        try:
            # Obtém último bloco
            latest_block = blockchain_integration.get_latest_block()
            
            if latest_block["status"] != "success":
                return {"status": "error", "message": "Erro ao obter dados da rede"}
            
            block_data = latest_block["data"]
            
            # Obtém estatísticas adicionais
            network_stats = {
                "latest_block": {
                    "height": block_data.get("height"),
                    "hash": block_data.get("hash"),
                    "time": block_data.get("time"),
                    "tx_count": block_data.get("n_tx"),
                    "size": block_data.get("size"),
                    "weight": block_data.get("weight")
                },
                "difficulty": block_data.get("bits"),
                "network": "mainnet",
                "last_updated": datetime.now().isoformat()
            }
            
            # Tenta obter mempool info
            try:
                mempool_url = "https://blockstream.info/api/mempool"
                response = requests.get(mempool_url, timeout=10)
                if response.status_code == 200:
                    mempool_data = response.json()
                    network_stats["mempool"] = {
                        "count": mempool_data.get("count", 0),
                        "vsize": mempool_data.get("vsize", 0),
                        "total_fee": mempool_data.get("total_fee", 0)
                    }
            except:
                network_stats["mempool"] = {"status": "unavailable"}
            
            return {
                "status": "success",
                "network_stats": network_stats
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas da rede: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def _get_btc_price(self):
        """Obtém preço atual do Bitcoin em USD"""
        try:
            # Tenta várias APIs para obter preço
            apis = [
                "https://api.coindesk.com/v1/bpi/currentprice.json",
                "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd"
            ]
            
            for api_url in apis:
                try:
                    response = requests.get(api_url, timeout=10)
                    if response.status_code == 200:
                        data = response.json()
                        
                        if "coindesk" in api_url:
                            price_str = data["bpi"]["USD"]["rate"].replace(",", "").replace("$", "")
                            return float(price_str)
                        elif "coingecko" in api_url:
                            return float(data["bitcoin"]["usd"])
                            
                except:
                    continue
            
            return None
            
        except Exception as e:
            logger.error(f"Erro ao obter preço do Bitcoin: {str(e)}")
            return None
    
    def get_custody_report(self):
        """Gera relatório da carteira de custódia"""
        try:
            # Obtém dados da carteira de custódia
            custody_balance = blockchain_integration.get_address_balance(self.custody_address)
            
            if custody_balance["status"] != "success":
                return {"status": "error", "message": "Erro ao obter dados da custódia"}
            
            current_balance = custody_balance["data"]["balance_btc"]
            
            # Obtém transações recentes
            custody_transactions = blockchain_integration.get_address_transactions(self.custody_address, limit=50)
            
            report = {
                "custody_address": self.custody_address,
                "current_balance_btc": current_balance,
                "expected_balance_btc": self.expected_custody_balance,
                "balance_difference": current_balance - self.expected_custody_balance,
                "balance_status": "ok" if abs(current_balance - self.expected_custody_balance) < 0.001 else "discrepancy",
                "last_updated": datetime.now().isoformat(),
                "transactions_count": 0,
                "recent_activity": []
            }
            
            if custody_transactions["status"] == "success":
                transactions = custody_transactions["data"]["transactions"]
                report["transactions_count"] = len(transactions)
                
                # Processa últimas 10 transações
                for tx in transactions[:10]:
                    report["recent_activity"].append({
                        "txid": tx.get("hash"),
                        "time": tx.get("time"),
                        "block_height": tx.get("block_height"),
                        "fee": tx.get("fee", 0),
                        "inputs_count": len(tx.get("inputs", [])),
                        "outputs_count": len(tx.get("out", []))
                    })
            
            return {
                "status": "success",
                "custody_report": report
            }
            
        except Exception as e:
            logger.error(f"Erro ao gerar relatório de custódia: {str(e)}")
            return {"status": "error", "message": str(e)}

# Instância global
dashboard_data = QuantumDashboardData()

# Rotas da API

@dashboard_bp.route('/portfolio', methods=['GET'])
def get_portfolio():
    """Endpoint para obter visão geral do portfólio"""
    result = dashboard_data.get_portfolio_overview()
    return jsonify(result)

@dashboard_bp.route('/transactions/recent', methods=['GET'])
def get_recent_transactions():
    """Endpoint para obter transações recentes"""
    limit = request.args.get('limit', 20, type=int)
    result = dashboard_data.get_recent_transactions(limit)
    return jsonify(result)

@dashboard_bp.route('/network/stats', methods=['GET'])
def get_network_stats():
    """Endpoint para obter estatísticas da rede"""
    result = dashboard_data.get_network_stats()
    return jsonify(result)

@dashboard_bp.route('/custody/report', methods=['GET'])
def get_custody_report():
    """Endpoint para obter relatório da custódia"""
    result = dashboard_data.get_custody_report()
    return jsonify(result)

@dashboard_bp.route('/summary', methods=['GET'])
def get_dashboard_summary():
    """Endpoint para obter resumo completo do dashboard"""
    try:
        # Obtém todos os dados principais
        portfolio = dashboard_data.get_portfolio_overview()
        recent_txs = dashboard_data.get_recent_transactions(10)
        network_stats = dashboard_data.get_network_stats()
        custody_report = dashboard_data.get_custody_report()
        
        summary = {
            "status": "success",
            "timestamp": datetime.now().isoformat(),
            "portfolio": portfolio.get("portfolio") if portfolio["status"] == "success" else None,
            "recent_transactions": recent_txs.get("transactions", []) if recent_txs["status"] == "success" else [],
            "network_stats": network_stats.get("network_stats") if network_stats["status"] == "success" else None,
            "custody_report": custody_report.get("custody_report") if custody_report["status"] == "success" else None,
            "system_status": {
                "portfolio_api": portfolio["status"],
                "transactions_api": recent_txs["status"],
                "network_api": network_stats["status"],
                "custody_api": custody_report["status"]
            }
        }
        
        return jsonify(summary)
        
    except Exception as e:
        logger.error(f"Erro ao obter resumo do dashboard: {str(e)}")
        return jsonify({"error": str(e)}), 500

