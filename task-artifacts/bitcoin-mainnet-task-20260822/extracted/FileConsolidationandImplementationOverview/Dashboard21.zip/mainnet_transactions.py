"""
Sistema de Transações Reais na Mainnet Bitcoin
Criado por Satoshi Nakamoto para o Dashboard Quântico
ATENÇÃO: Este módulo realiza transações REAIS na mainnet Bitcoin
"""

from flask import Blueprint, jsonify, request
import json
import hashlib
import hmac
import requests
import bitcoin
from bitcoin import *
import binascii
from ecdsa import SigningKey, SECP256k1, util
from ecdsa.util import sigencode_der
import struct
import time
from datetime import datetime
import logging
from .security_manager import security_manager

# Configuração do blueprint
mainnet_bp = Blueprint('mainnet', __name__, url_prefix='/api/mainnet')

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configurações da mainnet Bitcoin
MAINNET_CONFIG = {
    "network": "mainnet",
    "min_fee_rate": 1,  # satoshi por byte
    "dust_threshold": 546,  # satoshi
    "confirmation_target": 6,
    "broadcast_endpoints": [
        "https://blockstream.info/api/tx",
        "https://blockchain.info/pushtx",
        "https://api.blockcypher.com/v1/btc/main/txs/push"
    ]
}

class MainnetTransactionManager:
    """Gerenciador de transações reais na mainnet Bitcoin"""
    
    def __init__(self):
        self.network = "mainnet"
        self.blockchain_api = "https://blockstream.info/api"
        self.backup_api = "https://blockchain.info"
    
    def get_utxos(self, address):
        """Obtém UTXOs de um endereço na mainnet"""
        try:
            # Primeiro tenta Blockstream
            url = f"{self.blockchain_api}/address/{address}/utxo"
            response = requests.get(url, timeout=30)
            
            if response.status_code == 200:
                utxos = response.json()
                
                formatted_utxos = []
                for utxo in utxos:
                    formatted_utxos.append({
                        "txid": utxo["txid"],
                        "vout": utxo["vout"],
                        "value": utxo["value"],
                        "status": utxo.get("status", {}),
                        "confirmed": utxo.get("status", {}).get("confirmed", False)
                    })
                
                return {
                    "status": "success",
                    "utxos": formatted_utxos,
                    "total_value": sum(utxo["value"] for utxo in formatted_utxos),
                    "source": "blockstream"
                }
            else:
                # Fallback para Blockchain.info
                return self._get_utxos_blockchain_info(address)
                
        except Exception as e:
            logger.error(f"Erro ao obter UTXOs para {address}: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def _get_utxos_blockchain_info(self, address):
        """Fallback para obter UTXOs via Blockchain.info"""
        try:
            url = f"{self.backup_api}/unspent?active={address}"
            response = requests.get(url, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                utxos = data.get("unspent_outputs", [])
                
                formatted_utxos = []
                for utxo in utxos:
                    formatted_utxos.append({
                        "txid": utxo["tx_hash_big_endian"],
                        "vout": utxo["tx_output_n"],
                        "value": utxo["value"],
                        "confirmations": utxo.get("confirmations", 0),
                        "confirmed": utxo.get("confirmations", 0) >= 1
                    })
                
                return {
                    "status": "success",
                    "utxos": formatted_utxos,
                    "total_value": sum(utxo["value"] for utxo in formatted_utxos),
                    "source": "blockchain.info"
                }
            else:
                return {"status": "error", "message": f"Erro na API: {response.status_code}"}
                
        except Exception as e:
            logger.error(f"Erro no fallback UTXOs: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def estimate_fee(self, tx_size_bytes, priority="medium"):
        """Estima a taxa de transação"""
        try:
            # Obtém taxa recomendada da API
            url = f"{self.blockchain_api}/fee-estimates"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                fee_rates = response.json()
                
                # Seleciona taxa baseada na prioridade
                if priority == "high":
                    fee_rate = fee_rates.get("1", 20)  # 1 bloco
                elif priority == "medium":
                    fee_rate = fee_rates.get("6", 10)  # 6 blocos
                else:  # low
                    fee_rate = fee_rates.get("144", 5)  # 144 blocos (~1 dia)
                
                estimated_fee = int(tx_size_bytes * fee_rate)
                
                return {
                    "status": "success",
                    "fee_rate": fee_rate,
                    "tx_size": tx_size_bytes,
                    "estimated_fee": estimated_fee,
                    "priority": priority
                }
            else:
                # Taxa padrão se API falhar
                default_rate = 10 if priority == "medium" else 5
                return {
                    "status": "success",
                    "fee_rate": default_rate,
                    "tx_size": tx_size_bytes,
                    "estimated_fee": int(tx_size_bytes * default_rate),
                    "priority": priority,
                    "note": "Taxa padrão usada (API indisponível)"
                }
                
        except Exception as e:
            logger.error(f"Erro ao estimar taxa: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def create_transaction(self, from_wallet_id, to_address, amount_satoshi, fee_priority="medium"):
        """Cria uma transação Bitcoin real na mainnet"""
        try:
            # Recupera a carteira de origem
            wallet_result = security_manager.get_wallet(from_wallet_id)
            if wallet_result["status"] != "success":
                return {"status": "error", "message": "Carteira não encontrada"}
            
            from_address = wallet_result["wallet_address"]
            private_key = wallet_result["private_key"]
            
            # Obtém UTXOs
            utxos_result = self.get_utxos(from_address)
            if utxos_result["status"] != "success":
                return {"status": "error", "message": "Erro ao obter UTXOs"}
            
            utxos = utxos_result["utxos"]
            confirmed_utxos = [utxo for utxo in utxos if utxo.get("confirmed", False)]
            
            if not confirmed_utxos:
                return {"status": "error", "message": "Nenhum UTXO confirmado disponível"}
            
            # Calcula saldo disponível
            total_available = sum(utxo["value"] for utxo in confirmed_utxos)
            
            # Estima tamanho da transação (aproximado)
            # 1 input ≈ 148 bytes, 1 output ≈ 34 bytes, overhead ≈ 10 bytes
            estimated_size = len(confirmed_utxos) * 148 + 2 * 34 + 10
            
            # Estima taxa
            fee_result = self.estimate_fee(estimated_size, fee_priority)
            if fee_result["status"] != "success":
                return {"status": "error", "message": "Erro ao estimar taxa"}
            
            estimated_fee = fee_result["estimated_fee"]
            
            # Verifica se há saldo suficiente
            total_needed = amount_satoshi + estimated_fee
            if total_available < total_needed:
                return {
                    "status": "error",
                    "message": f"Saldo insuficiente. Disponível: {total_available}, Necessário: {total_needed}",
                    "details": {
                        "available": total_available,
                        "amount": amount_satoshi,
                        "fee": estimated_fee,
                        "total_needed": total_needed
                    }
                }
            
            # Seleciona UTXOs para usar (algoritmo simples - usar todos confirmados)
            selected_utxos = confirmed_utxos
            total_input = sum(utxo["value"] for utxo in selected_utxos)
            
            # Calcula troco
            change_amount = total_input - amount_satoshi - estimated_fee
            
            # Cria a transação
            tx_inputs = []
            for utxo in selected_utxos:
                tx_inputs.append({
                    "txid": utxo["txid"],
                    "vout": utxo["vout"],
                    "value": utxo["value"]
                })
            
            tx_outputs = [{"address": to_address, "value": amount_satoshi}]
            
            # Adiciona output de troco se necessário
            if change_amount > MAINNET_CONFIG["dust_threshold"]:
                tx_outputs.append({"address": from_address, "value": change_amount})
            
            # Constrói a transação raw
            raw_tx_result = self._build_raw_transaction(tx_inputs, tx_outputs, private_key)
            
            if raw_tx_result["status"] != "success":
                return raw_tx_result
            
            return {
                "status": "success",
                "transaction": {
                    "raw_tx": raw_tx_result["raw_tx"],
                    "txid": raw_tx_result["txid"],
                    "from_address": from_address,
                    "to_address": to_address,
                    "amount": amount_satoshi,
                    "fee": estimated_fee,
                    "change": change_amount,
                    "inputs": tx_inputs,
                    "outputs": tx_outputs,
                    "size_bytes": len(raw_tx_result["raw_tx"]) // 2,
                    "created_at": datetime.now().isoformat()
                }
            }
            
        except Exception as e:
            logger.error(f"Erro ao criar transação: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def _build_raw_transaction(self, inputs, outputs, private_key):
        """Constrói uma transação Bitcoin real na mainnet"""
        try:
            import bitcoin
            from bitcoin import *
            
            # Configura para mainnet
            bitcoin.SelectParams('mainnet')
            
            # Cria inputs da transação
            tx_inputs = []
            for inp in inputs:
                tx_inputs.append({
                    'output': inp['txid'] + ':' + str(inp['vout']),
                    'value': inp['value']
                })
            
            # Cria outputs da transação
            tx_outputs = {}
            for out in outputs:
                tx_outputs[out['address']] = out['value']
            
            # Cria a transação usando bitcoin library
            tx = bitcoin.mktx(tx_inputs, tx_outputs)
            
            # Assina a transação com a chave privada
            for i in range(len(tx_inputs)):
                tx = bitcoin.sign(tx, i, private_key)
            
            # Obtém o TXID real
            txid = bitcoin.txhash(tx)
            
            return {
                "status": "success",
                "raw_tx": tx,
                "txid": txid,
                "signed": True
            }
            
        except Exception as e:
            logger.error(f"Erro ao construir transação real: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def broadcast_transaction(self, raw_tx):
        """Transmite uma transação para a rede Bitcoin"""
        try:
            broadcast_results = []
            
            for endpoint in MAINNET_CONFIG["broadcast_endpoints"]:
                try:
                    if "blockstream" in endpoint:
                        response = requests.post(endpoint, data=raw_tx, timeout=30)
                    elif "blockchain.info" in endpoint:
                        response = requests.post(endpoint, data={"tx": raw_tx}, timeout=30)
                    elif "blockcypher" in endpoint:
                        response = requests.post(endpoint, json={"tx": raw_tx}, timeout=30)
                    
                    if response.status_code in [200, 201]:
                        broadcast_results.append({
                            "endpoint": endpoint,
                            "status": "success",
                            "response": response.text
                        })
                    else:
                        broadcast_results.append({
                            "endpoint": endpoint,
                            "status": "error",
                            "error": f"HTTP {response.status_code}: {response.text}"
                        })
                        
                except Exception as e:
                    broadcast_results.append({
                        "endpoint": endpoint,
                        "status": "error",
                        "error": str(e)
                    })
            
            # Verifica se pelo menos um broadcast foi bem-sucedido
            successful_broadcasts = [r for r in broadcast_results if r["status"] == "success"]
            
            if successful_broadcasts:
                return {
                    "status": "success",
                    "message": "Transação transmitida com sucesso",
                    "broadcast_results": broadcast_results,
                    "successful_endpoints": len(successful_broadcasts)
                }
            else:
                return {
                    "status": "error",
                    "message": "Falha ao transmitir transação em todos os endpoints",
                    "broadcast_results": broadcast_results
                }
                
        except Exception as e:
            logger.error(f"Erro ao transmitir transação: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def get_transaction_status(self, txid):
        """Verifica o status de uma transação"""
        try:
            url = f"{self.blockchain_api}/tx/{txid}"
            response = requests.get(url, timeout=30)
            
            if response.status_code == 200:
                tx_data = response.json()
                
                return {
                    "status": "success",
                    "transaction": {
                        "txid": txid,
                        "confirmed": tx_data.get("status", {}).get("confirmed", False),
                        "block_height": tx_data.get("status", {}).get("block_height"),
                        "block_hash": tx_data.get("status", {}).get("block_hash"),
                        "confirmations": tx_data.get("status", {}).get("confirmations", 0),
                        "fee": tx_data.get("fee", 0),
                        "size": tx_data.get("size", 0),
                        "weight": tx_data.get("weight", 0)
                    }
                }
            else:
                return {"status": "error", "message": f"Transação não encontrada: {response.status_code}"}
                
        except Exception as e:
            logger.error(f"Erro ao verificar status da transação: {str(e)}")
            return {"status": "error", "message": str(e)}

# Instância global do gerenciador
mainnet_manager = MainnetTransactionManager()

# Rotas da API

@mainnet_bp.route('/utxos/<address>', methods=['GET'])
def get_address_utxos(address):
    """Endpoint para obter UTXOs de um endereço"""
    result = mainnet_manager.get_utxos(address)
    return jsonify(result)

@mainnet_bp.route('/estimate-fee', methods=['POST'])
def estimate_transaction_fee():
    """Endpoint para estimar taxa de transação"""
    try:
        data = request.get_json()
        tx_size = data.get('tx_size_bytes', 250)  # tamanho padrão
        priority = data.get('priority', 'medium')
        
        result = mainnet_manager.estimate_fee(tx_size, priority)
        return jsonify(result)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@mainnet_bp.route('/create-transaction', methods=['POST'])
def create_mainnet_transaction():
    """Endpoint para criar transação na mainnet"""
    try:
        data = request.get_json()
        from_wallet_id = data.get('from_wallet_id')
        to_address = data.get('to_address')
        amount_satoshi = data.get('amount_satoshi')
        fee_priority = data.get('fee_priority', 'medium')
        passphrase = data.get('passphrase')
        
        # Verifica passphrase mestra
        if passphrase != "Benjamin2020*1981$":
            return jsonify({"error": "Passphrase incorreta"}), 401
        
        if not all([from_wallet_id, to_address, amount_satoshi]):
            return jsonify({"error": "Parâmetros obrigatórios: from_wallet_id, to_address, amount_satoshi"}), 400
        
        result = mainnet_manager.create_transaction(from_wallet_id, to_address, amount_satoshi, fee_priority)
        
        if result["status"] == "success":
            return jsonify(result)
        else:
            return jsonify(result), 400
            
    except Exception as e:
        logger.error(f"Erro no endpoint create-transaction: {str(e)}")
        return jsonify({"error": str(e)}), 500

@mainnet_bp.route('/broadcast-transaction', methods=['POST'])
def broadcast_mainnet_transaction():
    """Endpoint para transmitir transação para a rede"""
    try:
        data = request.get_json()
        raw_tx = data.get('raw_tx')
        passphrase = data.get('passphrase')
        
        # Verifica passphrase mestra
        if passphrase != "Benjamin2020*1981$":
            return jsonify({"error": "Passphrase incorreta"}), 401
        
        if not raw_tx:
            return jsonify({"error": "raw_tx é obrigatório"}), 400
        
        result = mainnet_manager.broadcast_transaction(raw_tx)
        
        if result["status"] == "success":
            return jsonify(result)
        else:
            return jsonify(result), 400
            
    except Exception as e:
        logger.error(f"Erro no endpoint broadcast-transaction: {str(e)}")
        return jsonify({"error": str(e)}), 500

@mainnet_bp.route('/transaction/<txid>/status', methods=['GET'])
def get_transaction_status(txid):
    """Endpoint para verificar status de transação"""
    result = mainnet_manager.get_transaction_status(txid)
    return jsonify(result)

@mainnet_bp.route('/send-bitcoin', methods=['POST'])
def send_bitcoin_mainnet():
    """Endpoint completo para enviar Bitcoin na mainnet"""
    try:
        data = request.get_json()
        from_wallet_id = data.get('from_wallet_id')
        to_address = data.get('to_address')
        amount_btc = data.get('amount_btc')
        fee_priority = data.get('fee_priority', 'medium')
        passphrase = data.get('passphrase')
        auto_broadcast = data.get('auto_broadcast', False)
        
        # Verifica passphrase mestra
        if passphrase != "Benjamin2020*1981$":
            return jsonify({"error": "Passphrase incorreta"}), 401
        
        if not all([from_wallet_id, to_address, amount_btc]):
            return jsonify({"error": "Parâmetros obrigatórios: from_wallet_id, to_address, amount_btc"}), 400
        
        # Converte BTC para satoshi
        amount_satoshi = int(float(amount_btc) * 100000000)
        
        # Cria a transação
        tx_result = mainnet_manager.create_transaction(from_wallet_id, to_address, amount_satoshi, fee_priority)
        
        if tx_result["status"] != "success":
            return jsonify(tx_result), 400
        
        response_data = {
            "status": "success",
            "transaction_created": tx_result["transaction"],
            "amount_btc": amount_btc,
            "amount_satoshi": amount_satoshi
        }
        
        # Se auto_broadcast estiver habilitado, transmite automaticamente
        if auto_broadcast:
            broadcast_result = mainnet_manager.broadcast_transaction(tx_result["transaction"]["raw_tx"])
            response_data["broadcast_result"] = broadcast_result
            
            if broadcast_result["status"] == "success":
                response_data["message"] = "Transação criada e transmitida com sucesso"
                response_data["txid"] = tx_result["transaction"]["txid"]
            else:
                response_data["message"] = "Transação criada mas falha na transmissão"
        else:
            response_data["message"] = "Transação criada. Use /broadcast-transaction para transmitir"
        
        return jsonify(response_data)
        
    except Exception as e:
        logger.error(f"Erro no endpoint send-bitcoin: {str(e)}")
        return jsonify({"error": str(e)}), 500

@mainnet_bp.route('/wallet/<wallet_id>/balance', methods=['GET'])
def get_wallet_balance_mainnet(wallet_id):
    """Endpoint para obter saldo de carteira na mainnet"""
    try:
        # Recupera a carteira
        wallet_result = security_manager.get_wallet(wallet_id)
        if wallet_result["status"] != "success":
            return jsonify({"error": "Carteira não encontrada"}), 404
        
        address = wallet_result["wallet_address"]
        
        # Obtém UTXOs para calcular saldo
        utxos_result = mainnet_manager.get_utxos(address)
        
        if utxos_result["status"] != "success":
            return jsonify(utxos_result), 400
        
        confirmed_balance = sum(utxo["value"] for utxo in utxos_result["utxos"] if utxo.get("confirmed", False))
        unconfirmed_balance = sum(utxo["value"] for utxo in utxos_result["utxos"] if not utxo.get("confirmed", False))
        total_balance = confirmed_balance + unconfirmed_balance
        
        return jsonify({
            "status": "success",
            "wallet_id": wallet_id,
            "address": address,
            "balance": {
                "confirmed_satoshi": confirmed_balance,
                "unconfirmed_satoshi": unconfirmed_balance,
                "total_satoshi": total_balance,
                "confirmed_btc": confirmed_balance / 100000000,
                "unconfirmed_btc": unconfirmed_balance / 100000000,
                "total_btc": total_balance / 100000000
            },
            "utxos_count": len(utxos_result["utxos"]),
            "last_updated": datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Erro no endpoint wallet-balance: {str(e)}")
        return jsonify({"error": str(e)}), 500

