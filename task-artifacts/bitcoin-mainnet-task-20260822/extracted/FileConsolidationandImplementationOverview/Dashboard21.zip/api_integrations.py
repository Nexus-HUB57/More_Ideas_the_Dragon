"""
Módulo de integração com APIs externas (Binance, Blockchain, Blockcypher)
Criado por Satoshi Nakamoto para o Dashboard Quântico
"""

from flask import Blueprint, jsonify, request
import requests
import json
import time
from binance.client import Client
import blockcypher
from datetime import datetime
import logging

# Configuração do blueprint
api_integrations_bp = Blueprint('api_integrations', __name__, url_prefix='/api')

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BinanceIntegration:
    """Integração com a API da Binance para dados de custódia"""
    
    def __init__(self, api_key=None, api_secret=None):
        self.api_key = api_key
        self.api_secret = api_secret
        self.client = None
        if api_key and api_secret:
            self.client = Client(api_key, api_secret)
    
    def get_account_info(self):
        """Obtém informações da conta Binance"""
        try:
            if not self.client:
                return {"error": "Cliente Binance não configurado"}
            
            account = self.client.get_account()
            return {
                "status": "success",
                "data": {
                    "balances": account['balances'],
                    "account_type": account['accountType'],
                    "can_trade": account['canTrade'],
                    "can_withdraw": account['canWithdraw'],
                    "can_deposit": account['canDeposit']
                }
            }
        except Exception as e:
            logger.error(f"Erro ao obter informações da conta Binance: {str(e)}")
            return {"error": str(e)}
    
    def get_btc_balance(self):
        """Obtém o saldo de Bitcoin na Binance"""
        try:
            if not self.client:
                return {"error": "Cliente Binance não configurado"}
            
            balance = self.client.get_asset_balance(asset='BTC')
            return {
                "status": "success",
                "data": {
                    "asset": "BTC",
                    "free": balance['free'],
                    "locked": balance['locked'],
                    "total": float(balance['free']) + float(balance['locked'])
                }
            }
        except Exception as e:
            logger.error(f"Erro ao obter saldo BTC da Binance: {str(e)}")
            return {"error": str(e)}

class BlockchainIntegration:
    """Integração com a API principal da Blockchain para dados da mainnet"""
    
    def __init__(self):
        self.base_url = "https://blockchain.info"
        self.api_url = "https://api.blockchain.info/v1"
    
    def get_address_balance(self, address):
        """Obtém o saldo de um endereço Bitcoin"""
        try:
            url = f"{self.base_url}/q/addressbalance/{address}"
            response = requests.get(url, timeout=30)
            
            if response.status_code == 200:
                balance_satoshi = int(response.text)
                balance_btc = balance_satoshi / 100000000  # Conversão de satoshi para BTC
                return {
                    "status": "success",
                    "data": {
                        "address": address,
                        "balance_satoshi": balance_satoshi,
                        "balance_btc": balance_btc
                    }
                }
            else:
                return {"error": f"Erro na API: {response.status_code}"}
                
        except Exception as e:
            logger.error(f"Erro ao obter saldo do endereço {address}: {str(e)}")
            return {"error": str(e)}
    
    def get_address_transactions(self, address, limit=50):
        """Obtém as transações de um endereço"""
        try:
            url = f"{self.base_url}/rawaddr/{address}?limit={limit}"
            response = requests.get(url, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                return {
                    "status": "success",
                    "data": {
                        "address": address,
                        "n_tx": data.get('n_tx', 0),
                        "total_received": data.get('total_received', 0),
                        "total_sent": data.get('total_sent', 0),
                        "final_balance": data.get('final_balance', 0),
                        "transactions": data.get('txs', [])[:limit]
                    }
                }
            else:
                return {"error": f"Erro na API: {response.status_code}"}
                
        except Exception as e:
            logger.error(f"Erro ao obter transações do endereço {address}: {str(e)}")
            return {"error": str(e)}
    
    def get_latest_block(self):
        """Obtém informações do último bloco"""
        try:
            url = f"{self.base_url}/latestblock"
            response = requests.get(url, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                return {
                    "status": "success",
                    "data": data
                }
            else:
                return {"error": f"Erro na API: {response.status_code}"}
                
        except Exception as e:
            logger.error(f"Erro ao obter último bloco: {str(e)}")
            return {"error": str(e)}

class BlockcypherIntegration:
    """Integração com a API Blockcypher como fallback"""
    
    def __init__(self, api_token=None):
        self.api_token = api_token
        self.base_url = "https://api.blockcypher.com/v1/btc/main"
    
    def get_address_balance(self, address):
        """Obtém o saldo de um endereço Bitcoin via Blockcypher"""
        try:
            params = {}
            if self.api_token:
                params['token'] = self.api_token
            
            url = f"{self.base_url}/addrs/{address}/balance"
            response = requests.get(url, params=params, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                return {
                    "status": "success",
                    "data": {
                        "address": address,
                        "balance": data.get('balance', 0),
                        "unconfirmed_balance": data.get('unconfirmed_balance', 0),
                        "final_balance": data.get('final_balance', 0),
                        "n_tx": data.get('n_tx', 0),
                        "unconfirmed_n_tx": data.get('unconfirmed_n_tx', 0),
                        "final_n_tx": data.get('final_n_tx', 0)
                    }
                }
            else:
                return {"error": f"Erro na API Blockcypher: {response.status_code}"}
                
        except Exception as e:
            logger.error(f"Erro ao obter saldo via Blockcypher para {address}: {str(e)}")
            return {"error": str(e)}
    
    def get_address_transactions(self, address, limit=50):
        """Obtém transações de um endereço via Blockcypher"""
        try:
            params = {"limit": limit}
            if self.api_token:
                params['token'] = self.api_token
            
            url = f"{self.base_url}/addrs/{address}/full"
            response = requests.get(url, params=params, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                return {
                    "status": "success",
                    "data": data
                }
            else:
                return {"error": f"Erro na API Blockcypher: {response.status_code}"}
                
        except Exception as e:
            logger.error(f"Erro ao obter transações via Blockcypher para {address}: {str(e)}")
            return {"error": str(e)}

# Instâncias globais das integrações
binance_integration = BinanceIntegration()
blockchain_integration = BlockchainIntegration()
blockcypher_integration = BlockcypherIntegration()

# Rotas da API

@api_integrations_bp.route('/binance/account', methods=['GET'])
def get_binance_account():
    """Endpoint para obter informações da conta Binance"""
    result = binance_integration.get_account_info()
    return jsonify(result)

@api_integrations_bp.route('/binance/btc-balance', methods=['GET'])
def get_binance_btc_balance():
    """Endpoint para obter saldo BTC da Binance"""
    result = binance_integration.get_btc_balance()
    return jsonify(result)

@api_integrations_bp.route('/blockchain/address/<address>/balance', methods=['GET'])
def get_blockchain_address_balance(address):
    """Endpoint para obter saldo de endereço via Blockchain.info"""
    result = blockchain_integration.get_address_balance(address)
    return jsonify(result)

@api_integrations_bp.route('/blockchain/address/<address>/transactions', methods=['GET'])
def get_blockchain_address_transactions(address):
    """Endpoint para obter transações de endereço via Blockchain.info"""
    limit = request.args.get('limit', 50, type=int)
    result = blockchain_integration.get_address_transactions(address, limit)
    return jsonify(result)

@api_integrations_bp.route('/blockchain/latest-block', methods=['GET'])
def get_blockchain_latest_block():
    """Endpoint para obter informações do último bloco"""
    result = blockchain_integration.get_latest_block()
    return jsonify(result)

@api_integrations_bp.route('/blockcypher/address/<address>/balance', methods=['GET'])
def get_blockcypher_address_balance(address):
    """Endpoint para obter saldo de endereço via Blockcypher (fallback)"""
    result = blockcypher_integration.get_address_balance(address)
    return jsonify(result)

@api_integrations_bp.route('/blockcypher/address/<address>/transactions', methods=['GET'])
def get_blockcypher_address_transactions(address):
    """Endpoint para obter transações de endereço via Blockcypher (fallback)"""
    limit = request.args.get('limit', 50, type=int)
    result = blockcypher_integration.get_address_transactions(address, limit)
    return jsonify(result)

@api_integrations_bp.route('/consolidated-balance/<address>', methods=['GET'])
def get_consolidated_balance(address):
    """Endpoint para obter saldo consolidado usando múltiplas APIs"""
    
    # Primeiro tenta Blockchain.info
    blockchain_result = blockchain_integration.get_address_balance(address)
    
    if blockchain_result.get('status') == 'success':
        result = {
            "status": "success",
            "source": "blockchain.info",
            "data": blockchain_result['data']
        }
    else:
        # Se falhar, usa Blockcypher como fallback
        blockcypher_result = blockcypher_integration.get_address_balance(address)
        
        if blockcypher_result.get('status') == 'success':
            # Converte dados do Blockcypher para formato padrão
            data = blockcypher_result['data']
            result = {
                "status": "success",
                "source": "blockcypher",
                "data": {
                    "address": address,
                    "balance_satoshi": data.get('final_balance', 0),
                    "balance_btc": data.get('final_balance', 0) / 100000000
                }
            }
        else:
            result = {
                "status": "error",
                "message": "Falha em todas as APIs",
                "errors": {
                    "blockchain": blockchain_result.get('error'),
                    "blockcypher": blockcypher_result.get('error')
                }
            }
    
    return jsonify(result)

@api_integrations_bp.route('/custody-wallet-balance', methods=['GET'])
def get_custody_wallet_balance():
    """Endpoint para obter saldo da carteira de custódia principal"""
    # Endereço da carteira de custódia conforme documentação
    custody_address = "13m3xop6RnioRX6qrnkavLekv7cvu5DuMK"
    
    result = get_consolidated_balance(custody_address)
    
    # Adiciona informações específicas da custódia
    if result.get('status') == 'success':
        result['custody_info'] = {
            "address": custody_address,
            "type": "custody_wallet",
            "expected_balance_btc": 31089.84355968,  # Conforme relatório de consolidação
            "last_updated": datetime.now().isoformat()
        }
    
    return jsonify(result)

@api_integrations_bp.route('/configure-binance', methods=['POST'])
def configure_binance():
    """Endpoint para configurar credenciais da Binance"""
    try:
        data = request.get_json()
        api_key = data.get('api_key')
        api_secret = data.get('api_secret')
        
        if not api_key or not api_secret:
            return jsonify({"error": "API key e secret são obrigatórios"}), 400
        
        # Atualiza a instância global
        global binance_integration
        binance_integration = BinanceIntegration(api_key, api_secret)
        
        # Testa a conexão
        test_result = binance_integration.get_account_info()
        
        if test_result.get('status') == 'success':
            return jsonify({
                "status": "success",
                "message": "Binance configurada com sucesso"
            })
        else:
            return jsonify({
                "status": "error",
                "message": "Falha ao conectar com a Binance",
                "error": test_result.get('error')
            }), 400
            
    except Exception as e:
        logger.error(f"Erro ao configurar Binance: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_integrations_bp.route('/configure-blockcypher', methods=['POST'])
def configure_blockcypher():
    """Endpoint para configurar token da Blockcypher"""
    try:
        data = request.get_json()
        api_token = data.get('api_token')
        
        if not api_token:
            return jsonify({"error": "Token da API é obrigatório"}), 400
        
        # Atualiza a instância global
        global blockcypher_integration
        blockcypher_integration = BlockcypherIntegration(api_token)
        
        return jsonify({
            "status": "success",
            "message": "Blockcypher configurada com sucesso"
        })
        
    except Exception as e:
        logger.error(f"Erro ao configurar Blockcypher: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_integrations_bp.route('/health', methods=['GET'])
def api_health():
    """Endpoint para verificar saúde das APIs"""
    health_status = {
        "timestamp": datetime.now().isoformat(),
        "apis": {
            "binance": {
                "configured": binance_integration.client is not None,
                "status": "unknown"
            },
            "blockchain": {
                "configured": True,
                "status": "unknown"
            },
            "blockcypher": {
                "configured": blockcypher_integration.api_token is not None,
                "status": "unknown"
            }
        }
    }
    
    # Testa Blockchain.info
    try:
        blockchain_test = blockchain_integration.get_latest_block()
        health_status["apis"]["blockchain"]["status"] = "ok" if blockchain_test.get('status') == 'success' else "error"
    except:
        health_status["apis"]["blockchain"]["status"] = "error"
    
    # Testa Binance se configurada
    if binance_integration.client:
        try:
            binance_test = binance_integration.get_account_info()
            health_status["apis"]["binance"]["status"] = "ok" if binance_test.get('status') == 'success' else "error"
        except:
            health_status["apis"]["binance"]["status"] = "error"
    
    return jsonify(health_status)

