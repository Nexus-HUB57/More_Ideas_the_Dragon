import { VM } from "vm2";

export interface ExecutionResult {
  success: boolean;
  output: string;
  error?: string;
  executionTime: number;
  consoleOutput: string[];
}

/**
 * Executa código JavaScript de forma segura em um sandbox
 * Captura console.log, console.error e trata erros
 */
export async function executeJavaScriptSandboxed(
  code: string,
  timeout: number = 5000
): Promise<ExecutionResult> {
  const startTime = Date.now();
  const consoleOutput: string[] = [];

  try {
    // Criar sandbox com console customizado
    const sandbox = {
      console: {
        log: (...args: any[]) => {
          const output = args.map((arg) => {
            if (typeof arg === "object") {
              return JSON.stringify(arg, null, 2);
            }
            return String(arg);
          }).join(" ");
          consoleOutput.push(output);
        },
        error: (...args: any[]) => {
          const output = args.map((arg) => {
            if (typeof arg === "object") {
              return JSON.stringify(arg, null, 2);
            }
            return String(arg);
          }).join(" ");
          consoleOutput.push(`[ERROR] ${output}`);
        },
        warn: (...args: any[]) => {
          const output = args.map((arg) => String(arg)).join(" ");
          consoleOutput.push(`[WARN] ${output}`);
        },
        info: (...args: any[]) => {
          const output = args.map((arg) => String(arg)).join(" ");
          consoleOutput.push(`[INFO] ${output}`);
        },
      },
      // Funções úteis
      Math,
      JSON,
      Array,
      Object,
      String,
      Number,
      Boolean,
      Date,
      RegExp,
      Error,
      setTimeout: undefined, // Desabilitar timers
      setInterval: undefined,
      setImmediate: undefined,
      require: undefined, // Desabilitar require
      module: undefined,
      process: undefined,
      global: undefined,
    };

    const vm = new VM({
      timeout,
      sandbox,
      eval: false,
      wasm: false,
    });

    // Executar código
    const result = vm.run(code);

    const executionTime = Date.now() - startTime;

    return {
      success: true,
      output: result !== undefined ? String(result) : "",
      consoleOutput,
      executionTime,
    };
  } catch (error) {
    const executionTime = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : String(error);

    return {
      success: false,
      output: "",
      error: errorMessage,
      consoleOutput,
      executionTime,
    };
  }
}

/**
 * Executa código HTML com CSS e JavaScript de forma segura
 * Retorna HTML seguro para renderizar em iframe
 */
export async function executeHTMLSandboxed(
  html: string,
  timeout: number = 5000
): Promise<ExecutionResult> {
  const startTime = Date.now();
  const consoleOutput: string[] = [];

  try {
    // Validar HTML básico
    if (!html.includes("<") || !html.includes(">")) {
      throw new Error("Invalid HTML: missing tags");
    }

    // Sanitizar HTML removendo scripts perigosos
    let sanitized = html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
      .replace(/on\w+\s*=\s*["'][^"']*["']/gi, "")
      .replace(/on\w+\s*=\s*[^\s>]*/gi, "");

    // Adicionar wrapper com console capturado
    const wrappedHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
        </style>
      </head>
      <body>
        ${sanitized}
        <script>
          // Capturar console
          const logs = [];
          const originalLog = console.log;
          const originalError = console.error;
          
          console.log = function(...args) {
            logs.push(args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));
            originalLog.apply(console, args);
          };
          
          console.error = function(...args) {
            logs.push('[ERROR] ' + args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));
            originalError.apply(console, args);
          };
          
          // Armazenar logs no window para acesso posterior
          window.__logs = logs;
        </script>
      </body>
      </html>
    `;

    const executionTime = Date.now() - startTime;

    return {
      success: true,
      output: wrappedHTML,
      consoleOutput,
      executionTime,
    };
  } catch (error) {
    const executionTime = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : String(error);

    return {
      success: false,
      output: "",
      error: errorMessage,
      consoleOutput,
      executionTime,
    };
  }
}

/**
 * Executa código Python (simulado - requer integração com backend Python)
 * Por enquanto, retorna erro indicando que Python não está disponível
 */
export async function executePythonSandboxed(
  code: string,
  timeout: number = 5000
): Promise<ExecutionResult> {
  const executionTime = 0;

  return {
    success: false,
    output: "",
    error: "Python execution not available. Use Python backend API.",
    consoleOutput: [],
    executionTime,
  };
}

/**
 * Determina a linguagem e executa o código apropriado
 */
export async function executeCodeSandboxed(
  code: string,
  language: string,
  timeout: number = 5000
): Promise<ExecutionResult> {
  const lang = language.toLowerCase().trim();

  switch (lang) {
    case "javascript":
    case "js":
    case "typescript":
    case "ts":
      return executeJavaScriptSandboxed(code, timeout);

    case "html":
    case "html5":
    case "jsx":
    case "tsx":
      return executeHTMLSandboxed(code, timeout);

    case "python":
    case "py":
      return executePythonSandboxed(code, timeout);

    default:
      return {
        success: false,
        output: "",
        error: `Unsupported language: ${language}. Supported: JavaScript, HTML, Python`,
        consoleOutput: [],
        executionTime: 0,
      };
  }
}
