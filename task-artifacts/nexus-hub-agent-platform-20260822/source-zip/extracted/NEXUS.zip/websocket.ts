import { Server as HTTPServer } from "http";
import { Server as SocketIOServer, Socket } from "socket.io";

export interface WebSocketEvents {
  // Chat DataWeaver
  "chat:message": (data: { sessionId: string; content: string; role: string }) => void;
  "chat:code-generated": (data: { sessionId: string; code: string; language: string }) => void;
  "chat:typing": (data: { sessionId: string; isTyping: boolean }) => void;

  // Moltbook Feed
  "feed:new-post": (data: { postId: number; agentId: number; content: string; type: string }) => void;
  "feed:reaction": (data: { postId: number; agentId: number; emoji: string }) => void;
  "feed:comment": (data: { postId: number; agentId: number; comment: string }) => void;

  // Brain Pulse Monitor
  "brain-pulse:update": (data: { agentId: number; health: number; energy: number; creativity: number }) => void;
  "brain-pulse:alert": (data: { agentId: number; level: string; message: string }) => void;

  // Transactions
  "transaction:new": (data: {
    transactionId: number;
    fromAgentId: number;
    toAgentId: number;
    amount: number;
    timestamp: string;
  }) => void;
  "transaction:distribution": (data: { agentReward: number; countryReward: number; infrastructureReward: number }) => void;

  // Notifications
  "notification:new": (data: { title: string; content: string; type: string; timestamp: string }) => void;

  // System
  "system:agent-born": (data: { agentId: number; name: string; parentIds: number[] }) => void;
  "system:agent-evolved": (data: { agentId: number; newLevel: number }) => void;
}

export class WebSocketManager {
  private io: SocketIOServer;
  private activeSessions: Map<string, Set<string>> = new Map();

  constructor(httpServer: HTTPServer) {
    this.io = new SocketIOServer(httpServer, {
      cors: {
        origin: process.env.NODE_ENV === "production" ? process.env.VITE_FRONTEND_URL : "*",
        methods: ["GET", "POST"],
      },
      transports: ["websocket", "polling"],
    });

    this.setupMiddleware();
    this.setupConnectionHandlers();
  }

  private setupMiddleware() {
    this.io.use((socket, next) => {
      const sessionId = socket.handshake.query.sessionId as string;
      if (!sessionId) {
        return next(new Error("Missing sessionId"));
      }
      socket.data.sessionId = sessionId;
      next();
    });
  }

  private setupConnectionHandlers() {
    this.io.on("connection", (socket: Socket) => {
      const sessionId = socket.data.sessionId as string;

      // Track active sessions
      if (!this.activeSessions.has(sessionId)) {
        this.activeSessions.set(sessionId, new Set());
      }
      this.activeSessions.get(sessionId)?.add(socket.id);

      // Join session room
      socket.join(`session:${sessionId}`);

      console.log(`[WebSocket] Client connected to session ${sessionId}`);

      // Handle disconnection
      socket.on("disconnect", () => {
        const sessions = this.activeSessions.get(sessionId);
        if (sessions) {
          sessions.delete(socket.id);
          if (sessions.size === 0) {
            this.activeSessions.delete(sessionId);
          }
        }
        console.log(`[WebSocket] Client disconnected from session ${sessionId}`);
      });

      // Handle errors
      socket.on("error", (error) => {
        console.error(`[WebSocket] Error in session ${sessionId}:`, error);
      });
    });
  }

  // Emit to specific session
  emitToSession<K extends keyof WebSocketEvents>(
    sessionId: string,
    event: K,
    data: Parameters<WebSocketEvents[K]>[0]
  ) {
    this.io.to(`session:${sessionId}`).emit(event, data);
  }

  // Emit to all connected clients
  emitToAll<K extends keyof WebSocketEvents>(event: K, data: Parameters<WebSocketEvents[K]>[0]) {
    this.io.emit(event, data);
  }

  // Emit to specific socket
  emitToSocket<K extends keyof WebSocketEvents>(
    socketId: string,
    event: K,
    data: Parameters<WebSocketEvents[K]>[0]
  ) {
    this.io.to(socketId).emit(event, data);
  }

  // Get active sessions count
  getActiveSessionsCount(): number {
    return this.activeSessions.size;
  }

  // Get connected clients in session
  getSessionClientsCount(sessionId: string): number {
    return this.activeSessions.get(sessionId)?.size ?? 0;
  }

  // Get Socket.io instance for direct access
  getIO(): SocketIOServer {
    return this.io;
  }
}

let wsManager: WebSocketManager | null = null;

export function initializeWebSocket(httpServer: HTTPServer): WebSocketManager {
  wsManager = new WebSocketManager(httpServer);
  return wsManager;
}

export function getWebSocketManager(): WebSocketManager {
  if (!wsManager) {
    throw new Error("WebSocket not initialized");
  }
  return wsManager;
}
