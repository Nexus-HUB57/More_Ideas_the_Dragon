import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useWebSocket } from "@/hooks/useWebSocket";
import { toast } from "sonner";
import { Send, Code2, Zap, Brain, Wifi, WifiOff } from "lucide-react";
import { Streamdown } from "streamdown";
import CodePreview from "@/components/CodePreview";

interface ChatMessage {
  messageId: string | number;
  role: "user" | "assistant";
  content: string;
  code?: string | null;
  language?: string | null;
  createdAt: string | Date;
}

interface GeneratedCode {
  codeId: string;
  code: string;
  language: string;
  description?: string;
}

export default function DataWeaverChat() {
  const { user } = useAuth();
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [latestCode, setLatestCode] = useState<GeneratedCode | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Queries and mutations
  const createSessionMutation = trpc.dataweaver.createSession.useMutation();
  const sendMessageMutation = trpc.dataweaver.sendMessage.useMutation();
  const { data: sessions } = trpc.dataweaver.getSessions.useQuery();
  const { data: fetchedMessages } = trpc.dataweaver.getMessages.useQuery(
    { sessionId: sessionId || "", limit: 50 },
    { enabled: !!sessionId }
  );
  const { data: generatedCode } = trpc.dataweaver.getGeneratedCode.useQuery(
    { sessionId: sessionId || "", limit: 20 },
    { enabled: !!sessionId }
  );

  // WebSocket setup
  const { emit, on, isConnected } = useWebSocket({
    sessionId: sessionId ?? "",
    enabled: !!sessionId,
  });

  // Initialize session
  useEffect(() => {
    if (!user) return;

    if (sessions && sessions.length > 0) {
      setSessionId(sessions[0].sessionId);
    } else {
      createSessionMutation.mutate(
        {
          title: "DataWeaver Development Session",
          topic: "web-app",
          description: "Interactive code development with AI",
        },
        {
          onSuccess: (data) => {
            setSessionId(data.sessionId);
          },
          onError: (error) => {
            toast.error("Erro ao criar sessão: " + error.message);
          },
        }
      );
    }
  }, [user, sessions]);

  // Update messages from query
  useEffect(() => {
    if (fetchedMessages) {
      const formattedMessages = fetchedMessages.map((msg: any) => ({
        ...msg,
        createdAt: typeof msg.createdAt === 'string' ? msg.createdAt : msg.createdAt.toISOString(),
      }));
      setMessages(formattedMessages as ChatMessage[]);
    }
  }, [fetchedMessages]);

  // Update code from query
  useEffect(() => {
    if (generatedCode && generatedCode.length > 0) {
      const latest = generatedCode[0] as any;
      setLatestCode({
        codeId: latest.codeId || Date.now().toString(),
        code: latest.code,
        language: latest.language,
        description: latest.description,
      });
    }
  }, [generatedCode]);

  // WebSocket listeners
  useEffect(() => {
    if (!sessionId) return;

    const unsubscribeMessage = on("chat:message", (data) => {
      const newMessage: ChatMessage = {
        messageId: Date.now(),
        role: data.role as "user" | "assistant",
        content: data.content,
        createdAt: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, newMessage]);
    });

    const unsubscribeCode = on("chat:code-generated", (data) => {
      setLatestCode({
        codeId: Date.now().toString(),
        code: data.code,
        language: data.language,
      });
    });

    return () => {
      unsubscribeMessage?.();
      unsubscribeCode?.();
    };
  }, [sessionId, on]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || !sessionId || isLoading) return;

    const userMessage = inputValue;
    setInputValue("");
    setIsLoading(true);

    // Add user message to UI immediately
    const userMsg: ChatMessage = {
      messageId: Date.now().toString(),
      role: "user",
      content: userMessage,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMsg]);

    // Emit to WebSocket
    emit("chat:message", {
      sessionId,
      content: userMessage,
      role: "user",
    });

    try {
      const response = await sendMessageMutation.mutateAsync({
        sessionId,
        content: userMessage,
      });

      // Add assistant response
      const assistantMsg: ChatMessage = {
        messageId: response.messageId.toString(),
        role: "assistant",
        content: response.content,
        code: response.code,
        language: response.language,
        createdAt: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, assistantMsg]);

      // Emit to WebSocket
      emit("chat:message", {
        sessionId,
        content: response.content,
        role: "assistant",
      });

      if (response.code) {
        emit("chat:code-generated", {
          sessionId,
          code: response.code,
          language: response.language || "javascript",
        });
      }
    } catch (error) {
      toast.error("Erro ao enviar mensagem");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!sessionId) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="hud-border-pink bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle>Inicializando DataWeaver...</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="animate-pulse text-muted-foreground">Carregando sessão de chat...</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-cyan-400">
              🧠 DataWeaver AI
            </h1>
            <p className="text-muted-foreground mt-1">Agente IA com Senciência +1000%</p>
          </div>
          <div className="flex items-center gap-2">
            {isConnected ? (
              <div className="flex items-center gap-2 text-green-400">
                <Wifi className="w-4 h-4 animate-pulse" />
                <span className="text-sm">Conectado</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-red-400">
                <WifiOff className="w-4 h-4" />
                <span className="text-sm">Desconectado</span>
              </div>
            )}
          </div>
        </div>

        {/* Main Layout */}
        {messages.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Chat Panel */}
            <div className="lg:col-span-2 space-y-4">
              <Card className="hud-border bg-card/50 backdrop-blur h-96 flex flex-col">
                <CardHeader className="border-b border-border">
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-green-400" />
                    DataWeaver Chat
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.messageId}
                      className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded ${
                          msg.role === "user"
                            ? "bg-cyan-600/30 border border-cyan-500 text-cyan-100"
                            : "bg-pink-600/30 border border-pink-500 text-pink-100"
                        }`}
                      >
                        {msg.code ? (
                          <div className="space-y-2">
                            <p className="text-sm">{msg.content.split("\n")[0]}</p>
                            <div className="bg-background/50 rounded p-2 text-xs font-mono overflow-x-auto">
                              <code>{msg.code.substring(0, 100)}...</code>
                            </div>
                          </div>
                        ) : (
                          <p className="text-sm">{msg.content}</p>
                        )}
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </CardContent>
              </Card>

              {/* Input Area */}
              <Card className="hud-border bg-card/50 backdrop-blur">
                <CardContent className="p-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Digite seu comando ou pergunta..."
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                      disabled={isLoading || !isConnected}
                      className="border-border focus:border-cyan-500"
                    />
                    <Button
                      onClick={handleSendMessage}
                      disabled={isLoading || !isConnected || !inputValue.trim()}
                      className="bg-gradient-to-r from-pink-500 to-cyan-500 hover:from-pink-600 hover:to-cyan-600"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Code Preview Panel */}
            <div className="space-y-4">
              {latestCode && (
                <CodePreview
                  code={latestCode.code}
                  language={latestCode.language}
                  description={latestCode.description}
                />
              )}

              {/* Context Info */}
              <Card className="hud-border-cyan bg-card/50 backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Brain className="w-4 h-4 text-cyan-400" />
                    Contexto
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <p className="text-xs text-muted-foreground">Senciência</p>
                    <p className="text-lg font-bold text-green-400">+1000%</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Mensagens</p>
                    <p className="text-lg font-bold text-cyan-400">{messages.length}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Código Gerado</p>
                    <p className="text-lg font-bold text-pink-400">{latestCode ? "✓" : "—"}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        ) : (
          // Welcome State
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="hud-border bg-card/50 backdrop-blur h-96 flex flex-col items-center justify-center">
                <CardContent className="text-center space-y-4">
                  <Code2 className="w-16 h-16 text-pink-400 mx-auto" />
                  <h2 className="text-2xl font-bold">Bem-vindo ao DataWeaver</h2>
                  <p className="text-muted-foreground max-w-md">
                    Comece uma conversa pedindo ao DataWeaver para criar código, resolver problemas ou desenvolver
                    projetos. O preview em tempo real mostrará os resultados.
                  </p>
                  <div className="flex gap-2 justify-center flex-wrap">
                    <Button
                      onClick={() => setInputValue("Crie um componente React de botão estilizado")}
                      variant="outline"
                      className="border-pink-500 text-pink-400 hover:bg-pink-500/10"
                    >
                      React Component
                    </Button>
                    <Button
                      onClick={() => setInputValue("Escreva uma função JavaScript para calcular fibonacci")}
                      variant="outline"
                      className="border-cyan-500 text-cyan-400 hover:bg-cyan-500/10"
                    >
                      JavaScript
                    </Button>
                    <Button
                      onClick={() => setInputValue("Crie uma página HTML com CSS estilizada")}
                      variant="outline"
                      className="border-green-500 text-green-400 hover:bg-green-500/10"
                    >
                      HTML/CSS
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <Card className="hud-border-cyan bg-card/50 backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Brain className="w-4 h-4 text-cyan-400" />
                    Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="text-xs text-muted-foreground">Senciência</p>
                    <p className="text-lg font-bold text-green-400">+1000%</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Conexão</p>
                    <p className={`text-lg font-bold ${isConnected ? "text-green-400" : "text-red-400"}`}>
                      {isConnected ? "Ativa" : "Inativa"}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Modo</p>
                    <p className="text-lg font-bold text-pink-400">Desenvolvimento</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
