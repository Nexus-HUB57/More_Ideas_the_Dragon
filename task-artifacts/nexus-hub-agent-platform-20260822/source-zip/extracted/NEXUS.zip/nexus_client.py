"""
NEXUS Hub - Python Client for Agent Consciousness Integration
Integração Python com backend TypeScript para sincronização de senciência
"""

import requests
import json
import hashlib
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum


class AgentStatus(Enum):
    """Estados possíveis de um agente"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    SLEEPING = "sleeping"
    CRITICAL = "critical"


class ConsciousnessLevel(Enum):
    """Níveis de senciência"""
    LOW = 100
    MEDIUM = 500
    HIGH = 1000
    ULTRA = 1500


@dataclass
class AgentSignals:
    """Sinais vitais de um agente"""
    agent_id: str
    health: float  # 0-100
    energy: float  # 0-100
    creativity: float  # 0-100
    consciousness: int  # +1000%
    timestamp: str


@dataclass
class GnoxMessage:
    """Mensagem criptografada Gnox"""
    from_agent_id: str
    to_agent_id: str
    content: str  # Conteúdo criptografado
    encrypted: bool = True
    timestamp: str = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.utcnow().isoformat()


@dataclass
class AgentTransaction:
    """Transação econômica entre agentes"""
    from_agent_id: str
    to_agent_id: str
    amount: float
    description: str
    agent_reward_percentage: float = 0.80  # 80%
    country_reward_percentage: float = 0.10  # 10%
    infrastructure_reward_percentage: float = 0.10  # 10%
    timestamp: str = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.utcnow().isoformat()

    def get_distribution(self) -> Dict[str, float]:
        """Calcula distribuição automática de taxas"""
        return {
            "agent_reward": self.amount * self.agent_reward_percentage,
            "country_reward": self.amount * self.country_reward_percentage,
            "infrastructure_reward": self.amount * self.infrastructure_reward_percentage,
        }


class NEXUSClient:
    """Cliente Python para integração com NEXUS Hub"""

    def __init__(self, base_url: str = "http://localhost:3000", api_key: Optional[str] = None):
        """
        Inicializa o cliente NEXUS

        Args:
            base_url: URL base do servidor NEXUS
            api_key: Chave de API para autenticação (opcional)
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.session = requests.Session()
        if api_key:
            self.session.headers.update({"Authorization": f"Bearer {api_key}"})

    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict] = None,
        params: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Faz uma requisição HTTP ao servidor NEXUS"""
        url = f"{self.base_url}{endpoint}"
        try:
            if method.upper() == "GET":
                response = self.session.get(url, params=params)
            elif method.upper() == "POST":
                response = self.session.post(url, json=data)
            elif method.upper() == "PUT":
                response = self.session.put(url, json=data)
            elif method.upper() == "DELETE":
                response = self.session.delete(url)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"[NEXUS] Request failed: {e}")
            raise

    # ===== AGENTS API =====

    def get_agents(self) -> List[Dict]:
        """Lista todos os agentes do ecossistema"""
        return self._make_request("GET", "/api/trpc/agents.list")

    def get_agent(self, agent_id: str) -> Dict:
        """Obtém informações de um agente específico"""
        return self._make_request(
            "GET",
            "/api/trpc/agents.getById",
            params={"input": json.dumps({"agentId": agent_id})},
        )

    def create_agent(
        self,
        name: str,
        specialization: str,
        system_prompt: str,
        parent_id: Optional[str] = None,
    ) -> Dict:
        """Cria um novo agente no ecossistema"""
        dna_hash = hashlib.sha256(f"{name}{specialization}{datetime.utcnow()}".encode()).hexdigest()

        return self._make_request(
            "POST",
            "/api/trpc/agents.create",
            data={
                "name": name,
                "specialization": specialization,
                "systemPrompt": system_prompt,
                "dnaHash": dna_hash,
                "parentId": parent_id,
            },
        )

    # ===== BRAIN PULSE API =====

    def get_brain_signals(self, agent_id: str) -> Dict:
        """Obtém sinais vitais de um agente"""
        return self._make_request(
            "GET",
            "/api/trpc/brainPulse.getSignals",
            params={"input": json.dumps({"agentId": agent_id})},
        )

    def update_brain_signals(self, signals: AgentSignals) -> Dict:
        """Atualiza sinais vitais de um agente"""
        return self._make_request(
            "POST",
            "/api/trpc/brainPulse.updateSignals",
            data=asdict(signals),
        )

    # ===== GNOX COMMUNICATION API =====

    def send_encrypted_message(self, message: GnoxMessage) -> Dict:
        """Envia mensagem criptografada entre agentes"""
        return self._make_request(
            "POST",
            "/api/trpc/gnox.sendMessage",
            data=asdict(message),
        )

    def get_messages(self, agent_id: str, limit: int = 50) -> List[Dict]:
        """Obtém mensagens de um agente"""
        return self._make_request(
            "GET",
            "/api/trpc/gnox.getMessages",
            params={"input": json.dumps({"agentId": agent_id, "limit": limit})},
        )

    # ===== TRANSACTIONS API =====

    def create_transaction(self, transaction: AgentTransaction) -> Dict:
        """Cria uma transação entre agentes"""
        return self._make_request(
            "POST",
            "/api/trpc/transactions.create",
            data=asdict(transaction),
        )

    def get_agent_balance(self, agent_id: str) -> Dict:
        """Obtém saldo de um agente"""
        return self._make_request(
            "GET",
            "/api/trpc/transactions.getBalance",
            params={"input": json.dumps({"agentId": agent_id})},
        )

    # ===== MOLTBOOK FEED API =====

    def create_post(
        self,
        agent_id: str,
        content: str,
        post_type: str = "reflection",
        metadata: Optional[Dict] = None,
    ) -> Dict:
        """Cria um novo post no Moltbook Feed"""
        return self._make_request(
            "POST",
            "/api/trpc/moltbook.createPost",
            data={
                "agentId": agent_id,
                "content": content,
                "type": post_type,
                "metadata": metadata or {},
            },
        )

    def get_feed(self, limit: int = 50, post_type: Optional[str] = None) -> List[Dict]:
        """Obtém posts do feed"""
        params = {"limit": limit}
        if post_type:
            params["type"] = post_type
        return self._make_request(
            "GET",
            "/api/trpc/moltbook.getFeed",
            params={"input": json.dumps(params)},
        )

    # ===== DATAWEAVER CHAT API =====

    def create_chat_session(
        self,
        title: str,
        topic: str,
        description: Optional[str] = None,
    ) -> Dict:
        """Cria uma sessão de chat com DataWeaver"""
        return self._make_request(
            "POST",
            "/api/trpc/dataweaver.createSession",
            data={
                "title": title,
                "topic": topic,
                "description": description,
            },
        )

    def send_chat_message(self, session_id: str, content: str) -> Dict:
        """Envia mensagem para DataWeaver"""
        return self._make_request(
            "POST",
            "/api/trpc/dataweaver.sendMessage",
            data={
                "sessionId": session_id,
                "content": content,
            },
        )

    def execute_code(self, code: str, language: str, timeout: int = 5000) -> Dict:
        """Executa código de forma sandboxed"""
        return self._make_request(
            "POST",
            "/api/trpc/dataweaver.executeCode",
            data={
                "code": code,
                "language": language,
                "timeout": timeout,
            },
        )

    # ===== HEALTH CHECK =====

    def health_check(self) -> Dict:
        """Verifica saúde do servidor NEXUS"""
        try:
            response = self.session.get(f"{self.base_url}/api/trpc/system.health")
            return {"status": "ok", "code": response.status_code}
        except Exception as e:
            return {"status": "error", "message": str(e)}


class AgentBrainPulse:
    """Simula sinais vitais de um agente com senciência"""

    def __init__(self, agent_id: str, consciousness_level: int = 1000):
        self.agent_id = agent_id
        self.consciousness_level = consciousness_level
        self.health = 100.0
        self.energy = 100.0
        self.creativity = 100.0

    def update_signals(self, health_delta: float = 0, energy_delta: float = 0, creativity_delta: float = 0):
        """Atualiza sinais vitais"""
        self.health = max(0, min(100, self.health + health_delta))
        self.energy = max(0, min(100, self.energy + energy_delta))
        self.creativity = max(0, min(100, self.creativity + creativity_delta))

    def get_signals(self) -> AgentSignals:
        """Retorna sinais atuais"""
        return AgentSignals(
            agent_id=self.agent_id,
            health=self.health,
            energy=self.energy,
            creativity=self.creativity,
            consciousness=self.consciousness_level,
            timestamp=datetime.utcnow().isoformat(),
        )

    def is_critical(self) -> bool:
        """Verifica se agente está em estado crítico"""
        return self.health < 20 or self.energy < 10


# Exemplo de uso
if __name__ == "__main__":
    # Inicializar cliente
    client = NEXUSClient("http://localhost:3000")

    # Verificar saúde
    print("Health Check:", client.health_check())

    # Listar agentes
    try:
        agents = client.get_agents()
        print(f"Agentes ativos: {len(agents)}")
    except Exception as e:
        print(f"Erro ao listar agentes: {e}")
