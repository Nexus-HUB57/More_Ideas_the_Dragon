import { useEffect, useRef, useCallback } from "react";
import { io, Socket } from "socket.io-client";
import type { WebSocketEvents } from "../../../server/websocket";

interface UseWebSocketOptions {
  sessionId: string;
  enabled?: boolean;
}

export function useWebSocket({ sessionId, enabled = true }: UseWebSocketOptions) {
  const socketRef = useRef<Socket | null>(null);
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;

  useEffect(() => {
    if (!enabled || !sessionId) return;

    // Connect to WebSocket
    const socket = io(window.location.origin, {
      query: { sessionId },
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: maxReconnectAttempts,
      transports: ["websocket", "polling"],
    });

    socket.on("connect", () => {
      console.log(`[WebSocket] Connected to session ${sessionId}`);
      reconnectAttempts.current = 0;
    });

    socket.on("disconnect", (reason) => {
      console.log(`[WebSocket] Disconnected: ${reason}`);
    });

    socket.on("connect_error", (error) => {
      console.error(`[WebSocket] Connection error:`, error);
      reconnectAttempts.current++;
    });

    socketRef.current = socket;

    return () => {
      socket.disconnect();
    };
  }, [sessionId, enabled]);

  const emit = useCallback(
    <K extends keyof WebSocketEvents>(event: K, data: Parameters<WebSocketEvents[K]>[0]) => {
      if (socketRef.current?.connected) {
        socketRef.current.emit(event, data);
      } else {
        console.warn(`[WebSocket] Socket not connected, cannot emit ${String(event)}`);
      }
    },
    []
  );

  const on = useCallback(
    <K extends keyof WebSocketEvents>(event: K, callback: (data: any) => void) => {
      if (!socketRef.current) return;

      socketRef.current.on(event as any, callback);

      return () => {
        socketRef.current?.off(event as any, callback);
      };
    },
    []
  );

  const isConnected = socketRef.current?.connected ?? false;

  return { emit, on, isConnected, socket: socketRef.current };
}
