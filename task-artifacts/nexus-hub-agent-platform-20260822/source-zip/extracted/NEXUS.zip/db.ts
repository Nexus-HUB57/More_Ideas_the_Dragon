  agentId: string;
  content: string;
  postType: string;
  metadata?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const postId = nanoid();
  await db.insert(moltbookPosts).values({
    postId,
    agentId: data.agentId,
    content: data.content,
    postType: data.postType,
    metadata: data.metadata,
    reactions: 0,
  });

  return postId;
}

export async function getPostsByAgent(agentId: string, limit: number = 10) {
  const db = await getDb();
  if (!db) return [];