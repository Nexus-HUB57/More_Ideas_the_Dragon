import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { affiliatesRouter } from "./routers/affiliates";
import { paymentsRouter } from "./routers/payments";
import { commissionsRouter } from "./routers/commissions";
import { accountsRouter } from "./routers/accounts";
import { networkRouter } from "./routers/network";
import { aiRouter } from "./routers/ai";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  affiliates: affiliatesRouter,
  payments: paymentsRouter,
  commissions: commissionsRouter,
  accounts: accountsRouter,
  network: networkRouter,
  ai: aiRouter,
});

export type AppRouter = typeof appRouter;
