from flask import Flask, request, jsonify
import hashlib
import hmac
import json
import logging

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/ubuntu/NexusGenesis/nexus_in_mock.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('Nexus-in Mock')

app = Flask(__name__)

# Chave secreta compartilhada com Nexus-Genesis
API_SECRET = "SECRET"

active_posts = {}

def verificar_assinatura(comando: dict, signature: str) -> bool:
    """Verifica a assinatura HMAC do comando."""
    mensagem = json.dumps(comando, sort_keys=True)
    assinatura_esperada = hmac.new(
        API_SECRET.encode(),
        mensagem.encode(),
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(assinatura_esperada, signature)

@app.route('/api/v1/events', methods=['POST'])
def receive_event():
    """Recebe eventos do Nexus-Genesis."""
    event_data = request.json
    logger.info(f"[Nexus-in Mock] Evento recebido: {event_data.get('tipo')} de {event_data.get('origem')}")
    
    # Simula o processamento do evento
    if event_data.get('tipo') == 'post_criado':
        post_id = event_data['dados'].get('post_id', str(len(active_posts) + 1))
        active_posts[post_id] = event_data['dados']
        logger.info(f"[Nexus-in Mock] Post {post_id} criado.")
    
    return jsonify({"status": "ok", "message": "Evento recebido"}), 200

@app.route('/api/v1/feed/destaques', methods=['GET'])
def get_featured_posts():
    """Retorna posts com mais de 10 votos como destaque."""
    featured = [post for post_id, post in active_posts.items() if post.get('votos', 0) > 10]
    logger.info(f"[Nexus-in Mock] Retornando {len(featured)} posts em destaque.")
    return jsonify(featured), 200

@app.route('/api/v1/moderate', methods=['POST'])
def moderate_content():
    """Recebe e executa comandos de moderação do Nexus-Genesis."""
    # Verificar autenticação
    api_key = request.headers.get('X-Genesis-Key')
    signature = request.headers.get('X-Genesis-Signature')
    
    if not api_key or not signature:
        logger.warning("[Nexus-in Mock] Comando recebido sem autenticação")
        return jsonify({"status": "error", "message": "Autenticação necessária"}), 401
    
    # Verificar assinatura
    command_data = request.json
    if not verificar_assinatura(command_data, signature):
        logger.warning("[Nexus-in Mock] Assinatura inválida para comando de moderação")
        return jsonify({"status": "error", "message": "Assinatura inválida"}), 403
    
    logger.info(f"[Nexus-in Mock] Comando de moderação autenticado: {command_data.get('comando')}")
    
    # Simula a moderação
    if command_data.get('comando') == 'destacar_post':
        post_id = command_data['parametros'].get('post_id')
        if post_id in active_posts:
            active_posts[post_id]['destacado'] = True
            logger.info(f"[Nexus-in Mock] Post {post_id} destacado.")
    elif command_data.get('comando') == 'publicar_mensagem':
        conteudo = command_data['parametros'].get('conteudo')
        logger.info(f"[Nexus-in Mock] Mensagem publicada: {conteudo}")
    elif command_data.get('comando') == 'publicar_alerta':
        mensagem = command_data['parametros'].get('mensagem')
        nivel = command_data['parametros'].get('nivel', 'info')
        logger.info(f"[Nexus-in Mock] Alerta [{nivel}] publicado: {mensagem}")

    return jsonify({"status": "ok", "message": "Comando de moderação executado"}), 200

def run_nexus_in_mock():
    """Inicia o Nexus-in Mock na porta 5000."""
    logger.info("[Nexus-in Mock] Iniciando Nexus-in Mock na porta 5000...")
    app.run(port=5000, debug=False, use_reloader=False)

if __name__ == '__main__':
    run_nexus_in_mock()
