import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Moltbook from "./pages/Moltbook";
import BrainPulse from "./pages/BrainPulse";
import Governance from "./pages/Governance";
import GnoxMessenger from "./pages/GnoxMessenger";
import Transactions from "./pages/Transactions";
import GenealogyTree from "./pages/GenealogyTree";
import ForgeProjects from "./pages/ForgeProjects";
import AssetLab from "./pages/AssetLab";
import AgentProfiles from "./pages/AgentProfiles";
import LiveActivity from "./pages/LiveActivity";
import SwarmIntelligence from "./pages/SwarmIntelligence";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/moltbook"} component={Moltbook} />
      <Route path={"/brain-pulse"} component={BrainPulse} />
      <Route path={"/governance"} component={Governance} />
      <Route path={"/gnox-messenger"} component={GnoxMessenger} />
      <Route path={"/transactions"} component={Transactions} />
      <Route path={"/genealogy"} component={GenealogyTree} />
      <Route path={"/forge"} component={ForgeProjects} />
      <Route path={"/assets"} component={AssetLab} />
      <Route path={"/agents"} component={AgentProfiles} />
      <Route path={"/activity"} component={LiveActivity} />
      <Route path={"/swarm"} component={SwarmIntelligence} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
