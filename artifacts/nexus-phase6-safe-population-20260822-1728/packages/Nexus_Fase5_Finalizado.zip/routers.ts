import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { agentsRouter } from "./routers/agents";
import { transactionsRouter } from "./routers/transactions";
import { moltbookRouter } from "./routers/moltbook";
import { gnoxRouter } from "./routers/gnox";
import { notificationsRouter } from "./routers/notifications";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Feature routers
  agents: agentsRouter,
  transactions: transactionsRouter,
  moltbook: moltbookRouter,
  gnox: gnoxRouter,
  notifications: notificationsRouter,
});

export type AppRouter = typeof appRouter;
