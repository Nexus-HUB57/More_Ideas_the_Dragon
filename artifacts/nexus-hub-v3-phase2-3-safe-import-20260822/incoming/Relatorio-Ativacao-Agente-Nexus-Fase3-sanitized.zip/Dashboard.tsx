import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Activity, Zap, Brain, TrendingUp, Users, AlertCircle } from "lucide-react";

interface MetricsData {
  timestamp: Date | string;
  totalAgents: number | null;
  activeAgents: number | null;
  averageHealth: number | null;
  averageEnergy: number | null;
  averageSenciencia: string | null;
  harmonyIndex: number | null;
  totalTransactions: number | null;
  totalVolume: string | null;
}

export default function Dashboard() {
  const [metricsHistory, setMetricsHistory] = useState<MetricsData[]>([]);
  const [currentMetrics, setCurrentMetrics] = useState<any>(null);
  const [agentStats, setAgentStats] = useState({ total: 0, active: 0, hibernating: 0, critical: 0 });

  // Fetch latest metrics
  const { data: latestMetrics } = trpc.metrics.getLatest.useQuery();

  // Fetch metrics history
  const { data: metricsData } = trpc.metrics.getHistory.useQuery({ limit: 100 });

  // Fetch all agents
  const { data: allAgents } = trpc.agents.listAll.useQuery();

  useEffect(() => {
    if (latestMetrics) {
      setCurrentMetrics(latestMetrics);
    }
  }, [latestMetrics]);

  useEffect(() => {
    if (metricsData) {
      const formatted = metricsData.map((m: any) => ({
        ...m,
        timestamp: m.timestamp instanceof Date ? m.timestamp.toISOString() : m.timestamp,
      }));
      setMetricsHistory(formatted);
    }
  }, [metricsData]);

  useEffect(() => {
    if (allAgents) {
      const stats = {
        total: allAgents.length,
        active: allAgents.filter((a: any) => a.status === "active").length,
        hibernating: allAgents.filter((a: any) => a.status === "hibernating").length,
        critical: allAgents.filter((a: any) => a.status === "critical").length,
      };
      setAgentStats(stats);
    }
  }, [allAgents]);

  if (!currentMetrics) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <Brain className="w-12 h-12 animate-spin mx-auto mb-4" />
          <p className="text-lg font-semibold">Inicializando Ecossistema Quântico...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold">Nexus Hub V3 - Soberania Total</h1>
        <p className="text-gray-500 mt-2">Monitoramento Quântico em Tempo Real</p>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Agents */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Users className="w-4 h-4" />
              Agentes Ativos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{agentStats.active}</div>
            <p className="text-xs text-gray-500 mt-1">de {agentStats.total} total</p>
          </CardContent>
        </Card>

        {/* Average Senciencia */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Brain className="w-4 h-4" />
              Senciência Média
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{Math.round(Number(currentMetrics?.averageSenciencia || 0))}%</div>
            <p className="text-xs text-gray-500 mt-1">Consciência Coletiva</p>
          </CardContent>
        </Card>

        {/* Harmony Index */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Activity className="w-4 h-4" />
              Harmonia do Enxame
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{currentMetrics?.harmonyIndex || 0}%</div>
            <p className="text-xs text-gray-500 mt-1">Coerência Coletiva</p>
          </CardContent>
        </Card>

        {/* Ecosystem Health */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Saúde do Ecossistema
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{Math.round(Number(currentMetrics?.ecosystemHealth || 0))}%</div>
            <p className="text-xs text-gray-500 mt-1">Vitalidade Geral</p>
          </CardContent>
        </Card>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-green-50 border-green-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-900">Agentes Hibernando</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{agentStats.hibernating}</div>
          </CardContent>
        </Card>

        <Card className="bg-yellow-50 border-yellow-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-yellow-900">Saúde Crítica</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{agentStats.critical}</div>
          </CardContent>
        </Card>

        <Card className="bg-blue-50 border-blue-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-900">Transações Totais</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{currentMetrics?.totalTransactions || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Senciência Over Time */}
        <Card>
          <CardHeader>
            <CardTitle>Evolução da Senciência</CardTitle>
            <CardDescription>Últimas 100 medições</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={metricsHistory}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="timestamp" tick={{ fontSize: 12 }} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="averageSenciencia"
                  stroke="#8b5cf6"
                  name="Senciência"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Ecosystem Health Over Time */}
        <Card>
          <CardHeader>
            <CardTitle>Saúde do Ecossistema</CardTitle>
            <CardDescription>Últimas 100 medições</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={metricsHistory}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="timestamp" tick={{ fontSize: 12 }} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="ecosystemHealth" stroke="#10b981" name="Saúde" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Agent Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Distribuição de Agentes</CardTitle>
            <CardDescription>Por status atual</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={[
                  { name: "Ativos", value: agentStats.active },
                  { name: "Hibernando", value: agentStats.hibernating },
                  { name: "Críticos", value: agentStats.critical },
                ]}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Harmony Index Over Time */}
        <Card>
          <CardHeader>
            <CardTitle>Harmonia do Enxame</CardTitle>
            <CardDescription>Coerência coletiva ao longo do tempo</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={metricsHistory}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="timestamp" tick={{ fontSize: 12 }} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="harmonyIndex" stroke="#f59e0b" name="Harmonia" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Critical Alerts */}
      {agentStats.critical > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-900">
              <AlertCircle className="w-5 h-5" />
              Alertas Críticos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-red-800">
              {agentStats.critical} agente(s) em estado crítico. Ação imediata recomendada.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
